import os
import json
import traceback
import subprocess
from tqdm import tqdm
from utils.manager_taos import TaosManager
from tools import *
from common.config import load_migration_settings


if __name__ == '__main__':
    memory_monitor_limit(10)

    migration_info = load_migration_settings('config/migration_info.json')
    tgt_taos = TaosManager(
        migration_info['dst_host'], 
        migration_info['dst_port'], 
        migration_info['dst_user'], 
        migration_info['dst_password']
    )
    
    init_json = {
        "host": migration_info['dst_host'], 
        "port": migration_info['dst_port'], 
        "user": migration_info['dst_user'], 
        "password": migration_info['dst_password']
    }
    init_json_path = f"./tmp/init_json.json"
    with open(init_json_path,"w",encoding="utf-8") as f:
        json.dump(init_json, f, ensure_ascii=False, indent=4)
    result = subprocess.run(["./init_db",init_json_path], 
                            check=True, 
                            capture_output=True, 
                            text=True)
    print(result.stdout)
    os.remove(init_json_path)
    with open('./config/downloaded_dict.json', 'r', encoding='utf-8') as f:
        downloaded_dict = json.load(f)

    # 上传数据
    for table, download_path in tqdm(downloaded_dict.items(), 
                                    total=len(downloaded_dict),
                                    desc="正在上传数据文件", 
                                    unit="文件"
                                    ):
        try:
            if 'tick' in table.lower():
                tgt_taos.insert_tick_csv_title(migration_info['database'],
                                            table,
                                            download_path)
                update_json('./config/undo_upload.json', table, download_path)
                os.remove(download_path)
            else:
                tgt_taos.insert_bar_csv_title(migration_info['database'],
                                            table,
                                            download_path)
                update_json('./config/undo_upload.json', table, download_path)
                os.remove(download_path)

        except Exception as e:
            traceback.print_exc() 
            update_json('./config/redo_upload.json', table, download_path)
            
    os.remove('./config/downloaded_dict.json')
    tgt_taos.close()
