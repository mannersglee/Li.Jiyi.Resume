# 编译数据库初始化脚本（与standardize_upload一致）
cd ../upload_simply
/usr/bin/g++-9 -std=c++17 -O2 init_db.cpp -Iinclude -ltaos -pthread -o ../data_migration/init_db
cd ../data_migration
chmod +x ./init_db

# 手动修改config/migration_info.json和config/src_config.json


# 开始迁移数据
python3 download.py
python3 upload.py

