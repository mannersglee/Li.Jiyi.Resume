import os
from datetime import datetime
from utils.manager_taos import TaosManager
from tools import *
from common.config import load_migration_settings

if __name__ == '__main__':
    memory_monitor_limit(10)
    os.makedirs('./tmp', exist_ok=True)

    migration_info = load_migration_settings('./config/migration_info.json')
        
    # 连接来源数据库
    src_taos = TaosManager(
        migration_info["src_host"],
        migration_info["src_port"],
        migration_info["src_user"],
        migration_info["src_password"])
    table_list = src_taos.get_all_table_name(migration_info['database'])
    mission_list = []
    for table in table_list:
        if 'tick' in table.lower():
            if migration_info['migratetick']:
                mission_list.append(table)
        elif migration_info['migratebar']:
            mission_list.append(table)
    # 下载数据
    cnt = 0
    print_interval = max(1,int(len(mission_list)/100))
    for table in mission_list:
        redo_list.append(table)
        download_path = f"./tmp/{table}.csv"
        df = src_taos.get_table_data_ts_batch(migration_info['database'],
                                   table,
                                   datetime.strptime(str(migration_info['start']), '%Y%m%d'), 
                                   datetime.strptime(str(migration_info['end']), '%Y%m%d'),
                                   migration_info['batch']
                                   )
        if len(df) > 0:
            df.to_csv(download_path,index = False)
            update_json('config/downloaded_dict.json', table, download_path)
        cnt +=1
        if cnt % print_interval == 0:
            print_with_time(f"下载进度: {cnt}/{len(mission_list)}") 
       
        
    src_taos.close()
  
    
