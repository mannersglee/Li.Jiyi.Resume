import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from common.taos_manager import TaosManager

__all__ = ["TaosManager"]
