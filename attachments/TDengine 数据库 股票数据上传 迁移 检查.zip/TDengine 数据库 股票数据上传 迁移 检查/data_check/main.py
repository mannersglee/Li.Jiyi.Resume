import os
from config.settings import *
from tools import *
from datetime import timedelta, time
import datetime
from taos_manager import taos_manager
import logging
import subprocess
import pandas as pd

import gc


def check_database(taos: taos_manager, database_list=database_list):
    exist_database_list = taos.get_database_list()
    missing = []
    for database in database_list:
        if database not in exist_database_list:
            missing.append(database)
    if len(missing) > 0:
        print(f"{taos.host} 缺失数据库: ",missing)
        json_path = taos.save_conn_config("./tmp")
        result = subprocess.run(["./init_db",json_path], 
                            check=True, 
                            capture_output=True, 
                            text=True)
        print(result.stdout)    

def self_check(df, trading_time, table_type:str):
    
    df['time'] = pd.to_datetime(df['ts']).dt.time
    if "bar" in table_type.lower():
        mask = (
            (
            # 检查是否在交易时间
            df['time'].between(trading_time[0], trading_time[1]) |
            df['time'].between(trading_time[2], trading_time[3]) |
            ((df['timeframe']==1440) & (df['time']==time(16,0,0)))
            )&
            (
            # 检查开高低收是否非空且为正数
            (df['open'].notna()) &
            (df['open'] > 0) &
            (df['high'].notna()) &
            (df['high'] > 0) &
            (df['low'] > 0) &
            (df['low'].notna()) &
            (df['close'] > 0) &
            (df['close'].notna())
            )
        )
    elif "tick" in table_type.lower():
        am_open_time = trading_time[0]
        am_close_time = trading_time[1]
        pm_open_time = trading_time[2]
        pm_close_time = trading_time[3]

        # 子条件1：交易时段内的有效价格数据
        trading_period_condition = (
            (df['lastprice'].notna()) &
            (df['lastprice'] > 0) &
            (
                # 补全括号：明确两个交易时段的「或」逻辑优先级
                ((df['time'] >= am_open_time) & (df['time'] < am_close_time)) |
                ((df['time'] >= pm_open_time) & (df['time'] < pm_close_time))
            )
        )
        
        # 子条件2：9:15到早间开盘前的时段
        pre_open_condition = (
            (df['time'] >= datetime.time(9, 15, 0)) & 
            (df['time'] < am_open_time)
        )
        
        mask = trading_period_condition | pre_open_condition
    valid_df = df[mask].drop(columns=['time'])
    invalid_df = df[~mask].drop(columns=['time'])
    invalid_ts_list = invalid_df["ts"].tolist()
    return valid_df,invalid_df,invalid_ts_list
    
def check_table(taos_dict: dict[str, taos_manager], database:str, table:str, table_type:str, error_data_path:str, start="19700101", end="23000101", is_onsistency_check=True):

    df_dict = {}
    missing_table_host_list = []
    os.makedirs(error_data_path,exist_ok=True)
    selfcheck_path = os.path.join(error_data_path,"selfcheck")
    os.makedirs(selfcheck_path,exist_ok=True)
    if is_onsistency_check:
        consistency_path = os.path.join(error_data_path,"consistency")
        os.makedirs(consistency_path,exist_ok=True)

    failed_selfcheck = []
    for host, taos_local in taos_dict.items():
        # 检查库是否存在
        check_database(taos_local)
        # 检查表是否存在
        if table not in taos_local.get_table_list(database):
            missing_table_host_list.append(host)
            continue
        
        # 表的自检
        df = taos_local.get_table(database,table,start,end)
        if len(df) <= 0: 
            missing_table_host_list.append(host)
            continue
        valid_df,invalid_df,invalid_ts_list = self_check(df,trading_time,table_type)
        if len(invalid_df) > 0:
            failed_selfcheck.append(host)
        df_dict[host] = valid_df.set_index("ts")
        for ts in invalid_ts_list:
            invalid_df.to_csv(os.path.join(selfcheck_path,f"{database}{table}.csv"),index=False)
            taos_local.delete_row(database,table,ts)
    if len(failed_selfcheck)> 0:
        print_with_time("未通过自检：")
        print(failed_selfcheck)

    correct_df = pd.DataFrame()
    # 表的一致性检查
    if len(df_dict) > 1 and is_onsistency_check:
        correct_df, error_df, sync_mission = check_dataframe_consistency(df_dict, original_host)
        if len(sync_mission) > 0:
            sync_mission.to_csv(os.path.join(consistency_path,f"{database}{table}.csv"),index=False)
        if len(sync_mission):
            print_with_time("未通过一致性检查：")
            print(error_df["host"].unique().tolist())
            # print(sync_mission["index"].unique().tolist())
            ts_list = sync_mission["index"].unique().tolist()
            for ts in ts_list:
                tmp_df = correct_df.reset_index().rename(columns={"index":"ts"})
                tmp_df = tmp_df[tmp_df["ts"] == ts]
                sql_cmd = make_insert_sql(tmp_df,database,table)
                dest_host_list = sync_mission[sync_mission["index"]==ts]["dest_host"].unique().tolist()
                for dest_host in dest_host_list:
                    try: taos_dict[dest_host].execute_sql(sql_cmd)
                    except Exception as exc:
                        logging.error(f"Insert row failed for {database}.{table} on {dest_host}: {exc}")
                        
            # for _, row in sync_mission.iterrows():
            #     try:
            #         tmp_df = correct_df.reset_index().rename(columns={"index":"ts"})
            #         # tmp_df.to_csv('test3.csv',index=False)
            #         tmp_df = tmp_df[tmp_df["ts"]==row["index"]]
            #         sql_cmd = make_insert_sql(tmp_df,database,table)
            #         # print(sql_cmd)
            #         taos_dict[row["dest_host"]].execute_sql(sql_cmd)
            #     except Exception as exc:
            #         logging.error(f"Insert row failed for {database}.{table} on {row["dest_host"]}: {exc}")
        
    # 将正确表上传到缺失的 host
    if len(missing_table_host_list) > 0 and len(missing_table_host_list) < len(taos_dict):
        src_df = correct_df if len(correct_df)>0 else taos_dict[original_host].get_table(database,table,start,end)
        print_with_time("缺失表：",)
        print(missing_table_host_list)
        for host in missing_table_host_list:
            if "bar" in table_type.lower():
                taos_dict[host].insert_bar_dataframe_title(database,table,src_df)
            if "tick" in table_type.lower():
                taos_dict[host].insert_tick_dataframe_title(database,table,src_df)
    del df_dict
    if 'correct_df' in locals():
        del correct_df
    gc.collect()

if __name__ == "__main__":
    os.makedirs("./tmp", exist_ok=True)
    os.makedirs("./output", exist_ok=True)

    print_with_time("数据库连接中...")
    memory_monitor_limit(10)
    

    taos_dict = {}
    for host, config in taos_config_dict.items():
        taos_local = taos_manager(**config)
        taos_dict[host] = taos_local
    
    print_with_time("数据库连接成功")

    
    for database in database_list:
        table_list = taos_local.get_table_list(database)
        cnt = 0
        for table in table_list:
            cnt+=1
            now = datetime.datetime.now()
            hour_step = timedelta(days=1)
            start_str = now.strftime("%Y%m%d")
            end_str = (now+hour_step).strftime("%Y%m%d")
            
            # start_str="20230501"
            # end_str="20230601"

            
            print_with_time(f"{cnt}/{len(table_list)} {database} {table} 检查 {start_str}-{end_str} 中...")
            if "tick" in table.lower(): 
                check_table(taos_dict,database,table,"tick",f"./output/{start_str}",start_str,end_str)
            else: 
                check_table(taos_dict,database,table,"bar",f"./output/{start_str}",start_str,end_str)
            
            if cnt % 5 == 0:  # 每处理 5 张表强制清理一次
                gc.collect()
            
        break
        

