import os

from main import check_table
from taos_manager import taos_manager


def smoke_check() -> None:
    config = {
        "host": os.environ["TAOS_HOST"],
        "port": int(os.getenv("TAOS_PORT", "6030")),
        "user": os.getenv("TAOS_USER", "root"),
        "password": os.getenv("TAOS_PASSWORD", ""),
    }
    database = os.getenv("TAOS_TEST_DATABASE", "txy_stock")
    table = os.getenv("TAOS_TEST_TABLE", "s000001_m1440")
    start = os.getenv("TAOS_TEST_START", "20230101")
    end = os.getenv("TAOS_TEST_END", "20230110")

    manager = taos_manager(**config)
    try:
        check_table({config["host"]: manager}, database, table, "bar", "./output/smoke", start, end)
    finally:
        manager.close()


if __name__ == "__main__":
    smoke_check()
