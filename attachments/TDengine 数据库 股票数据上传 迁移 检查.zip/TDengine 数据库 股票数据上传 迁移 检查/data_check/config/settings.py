import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from common.config import load_check_settings

_settings = load_check_settings()

taos_config_dict = _settings["taos_config_dict"]
original_host = _settings["original_host"]
database_list = _settings["database_list"]
trading_time = _settings["trading_time"]
