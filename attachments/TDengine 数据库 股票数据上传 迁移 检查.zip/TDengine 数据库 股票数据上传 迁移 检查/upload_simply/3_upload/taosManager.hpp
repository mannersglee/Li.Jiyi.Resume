#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>
#include <vector>
#include <algorithm>
#include <sstream>
#include <ctime>
#include <iomanip>
#include <stdio.h>
#include <string.h>
#include <bitset>
#include <unordered_map>
#include <chrono>
#include <regex>
#include <inttypes.h>
#include <stdlib.h>
#include <thread>
#include <iomanip> // 包含头文件以使用 get_time
#include <ctime>   // 添加头文件以使用 get_time+
#include <type_traits>  
#include <filesystem>
namespace fs = std::filesystem;

#include "taos.h"

#include "../2_standardize/tick.hpp"
#include "../2_standardize/bar.hpp"
#include "../2_standardize/toCsv.hpp"
#include "makeSQL.hpp"


typedef uint16_t VarDataLenT;

#define TSDB_NCHAR_SIZE sizeof(int32_t)
#define VARSTR_HEADER_SIZE sizeof(VarDataLenT)

#define GET_FLOAT_VAL(x) (*(float *)(x))
#define GET_DOUBLE_VAL(x) (*(double *)(x))

#define varDataLen(v) ((VarDataLenT *)(v))[0]

using namespace std;


struct TickUploadConfig { 
    string file_path;
    string exchange;
    string stockid;
    string transaction_type;
};

struct BarUploadConfig { 
    string file_path;
    string exchange;
    string stockid;
    int timeframe;
    string transaction_type;
    
};


class TaosSQL
{
private:
    TAOS *conn;

public:
    TaosSQL(TAOS *conn2)
    {
        conn = conn2;
    }
    TaosSQL(string ip, string userid, string password)
    {
        conn = taos_connect(ip.c_str(), userid.c_str(), password.c_str(), NULL, 0);
    }

    ~TaosSQL()
    {
        if (conn != NULL)
        {
            taos_close(conn);
        }
    }

    // 关闭连接
    void Close()
    {
        if (conn != NULL)
        {
            taos_close(conn);
            conn = NULL;
        }
    }

    // 创建数据库
    void create_database(const string &database_name)
    {
        // string sql_cmd = "create database if not exists " + database_name + " keep 36500";

        string sql_cmd = 
        "CREATE DATABASE IF NOT EXISTS "+ database_name +" BUFFER 1024 CACHEMODEL 'both' CACHESIZE 64 COMP 2 KEEP 36500d MAXROWS 8192 MINROWS 1000 PAGES 512 PAGESIZE 8 TSDB_PAGESIZE 16 PRECISION 'ms' WAL_LEVEL 2 WAL_FSYNC_PERIOD 3000 STT_TRIGGER 4 VGROUPS 4";

        taos_query(conn, sql_cmd.c_str());
    }

    // 使用数据库
    void use_database(const string &database_name)
    {
        string sql_cmd = "use " + database_name + ";";
        TAOS_RES *res = taos_query(conn, sql_cmd.c_str());
        if (res == NULL)
        {
            throw runtime_error("Failed to use database: " + string(taos_errstr(conn)));
        }
        // 释放资源
        taos_free_result(res);
    }

    // 创建 tick 超级表
    void create_tick_stable(const string &database_name, const string &stable_name, const string transaction_type){
        
        string sql_cmd;
        if (transaction_type == "STOCK")
            sql_cmd = 
            "create stable if not exists "
            + database_name + 
            "."
            + stable_name +
            "(" 
            + make_table_name_stock() +
            ")"
            " TAGS (STOCKID_TAG NCHAR(20));";
        else if (transaction_type=="ETF")
            sql_cmd = 
            "create stable if not exists "
            +database_name+
            "."
            +stable_name+
            "(" 
            +make_table_name_etf()+
            ")"
            " TAGS (STOCKID_TAG NCHAR(20));";
        else if (transaction_type=="INDEX")
            sql_cmd = 
            "create stable if not exists "
            +database_name+
            "."
            +stable_name+
            "(" 
            +make_table_name_index()+
            ")"
            " TAGS (STOCKID_TAG NCHAR(20));";
        else if (transaction_type=="BOND")
            sql_cmd = 
            "create stable if not exists "
            +database_name+
            "."
            +stable_name+
            "(" 
            +make_table_name_bond()+
            ")"
            " TAGS (STOCKID_TAG NCHAR(20));";

        TAOS_RES *res = taos_query(conn, sql_cmd.c_str());
        if (res == NULL || taos_errno(res) != 0)
        {
            cout<< taos_errstr(res)<<endl;
            cout<< sql_cmd<<endl;

            throw runtime_error("Failed to create stable: " + string(taos_errstr(conn)));
        }
        // 释放资源
        taos_free_result(res);
    }

    // 上传 tick 数据
    template <typename TickType>
    int UpdateTick(const vector<TickType> &tickData, const string &db_name) {
        if (tickData.empty()) {
            return 0;
        }

        auto upload_start = chrono::high_resolution_clock::now();
        
        const TickType& tick1 = tickData[0];
        const string stable_name = "txy_tick";
        const size_t BATCH_SIZE = 800;

        string fields_part = "("+make_columns(tick1)+")";
        string table_name = db_name + "." + tick1.StockID + "_tick";
        string tags_part = " using " + db_name + "." + stable_name + " tags ('" + tick1.StockID + "')";

        bool havingError = false;
        // 分批处理
        for (size_t i = 0; i < tickData.size(); i += BATCH_SIZE) {
            auto start = chrono::high_resolution_clock::now();

            size_t batch_end = min(i + BATCH_SIZE, tickData.size());
            ostringstream sql_stream;

            sql_stream << "INSERT INTO " << table_name << fields_part << tags_part << " VALUES ";

            for (size_t j = i; j < batch_end; ++j) {
                const auto& tick = tickData[j];
                sql_stream << "(" ;
                make_values(tick, sql_stream);
                sql_stream << ")";
                if (j != batch_end - 1) {
                    sql_stream << ",";
                }
            }

            sql_stream << ";";
            string sql_cmd = sql_stream.str();

            TAOS_RES *res = taos_query(conn, sql_cmd.c_str());
            if (res == NULL || taos_errno(res) != 0) {
                cerr << "Failed to insert tick data, stockid: " << tick1.StockID << ". Error: " << taos_errstr(res)<<endl;
                taos_free_result(res);

                std::string dir_path = "error/"+ tick1.TradingDay + "/tick";
                fs::create_directories(dir_path);
                string file_name = dir_path + "/" + tick1.StockID+"_"+tick1.Exchange;
                toCsv(file_name+".csv", tickData);
                
                
                ofstream outFile(file_name+".txt");
                if (outFile.is_open())
                {
                    outFile << sql_cmd.c_str();
                    outFile.close();
                    cerr << "Write error SQL to file: " << file_name<<endl;
                } 
                else {
                    cerr << "Failed to open error SQL file: " << file_name << ".txt"<<endl;
                }
                

                return -1;
            }

            taos_free_result(res);

            // auto end=chrono::high_resolution_clock::now();
            // auto duration=chrono::duration_cast<chrono::milliseconds>(end-start);
            // cout<< BATCH_SIZE <<" Ticks 上传耗时: "<<duration.count()<<"ms"<<endl;
        }
        
        auto upload_end = chrono::high_resolution_clock::now();
        auto upload_duration = chrono::duration_cast<chrono::milliseconds>(upload_end - upload_start);
        cout << tickData.front().StockID<<"(tick) "<<to_string(tickData.size())<<" "<<upload_duration.count()<<"ms"<<endl;

        return 0; 
    }
    
    // 创建bar超级表
    void create_bar_stable(const string &database_name, const string &stable_name, const string &transaction_type)
    {

        string sql_cmd = "create stable if not exists " + database_name + "." + stable_name + " (";
        
        if (transaction_type == "INDEX")
            sql_cmd += make_table_name_baseBar();
        else if(transaction_type == "STOCK")
            sql_cmd += make_table_name_stockBar();
        else if(transaction_type == "ETF")
            sql_cmd += make_table_name_etfBar();
        else if(transaction_type == "BOND")
            sql_cmd += make_table_name_bondBar();
        else {
            cerr<< "[ERROR] Not support transaction type: "<<transaction_type<<endl;
            return;
        }

        sql_cmd += ") TAGS (STOCKID_TAG NCHAR(20), TIMEFRAME_TAG INT);";
        TAOS_RES *res = taos_query(conn, sql_cmd.c_str());
        if (res == NULL || taos_errno(res) != 0)
        {
            cerr << "TDengine fails to create stable: " << database_name << "." << stable_name << ". Error: " << taos_errstr(res) << endl;
        }
        taos_free_result(res);
    }

    template <typename BarType>
    int UpdateBar(const vector<BarType> &barData, const string &db_name) {
        if (barData.empty()) {
            return 0;
        }

        auto upload_start = chrono::high_resolution_clock::now();

        

        const size_t BATCH_SIZE = 800;
        const BarType& bar1 = barData[0];
        const string table_name = db_name + "." + bar1.StockID + "_m" + to_string(bar1.timeframe);
        const string tags_part = " using " + db_name + ".txy_bar tags ('" + bar1.StockID + "'," + to_string(bar1.timeframe) + ")";

        const string fields_part = "("+make_columns(bar1)+")";

        bool havingError = false;

        // 分批处理
        for (size_t i = 0; i < barData.size(); i += BATCH_SIZE) {
            auto start = chrono::high_resolution_clock::now();

            size_t batch_end = min(i + BATCH_SIZE, barData.size());
            ostringstream sql_stream;

            sql_stream << "INSERT INTO " << table_name << fields_part << tags_part << " VALUES ";

            for (size_t j = i; j < batch_end; ++j) {
                const auto& bar = barData[j];

                sql_stream << "(";
                make_values(bar,sql_stream);
                sql_stream << ")";

                if (j != batch_end - 1) {
                    sql_stream << ",";
                }
            }

            sql_stream << ";";
            string sql_cmd = sql_stream.str();

            TAOS_RES* res = taos_query(conn, sql_cmd.c_str());
            if (res == nullptr || taos_errno(res) != 0) {
                cerr<< "Failed to insert bar data, stockid: " << bar1.StockID << ". Error: " << taos_errstr(res)<<endl;
                taos_free_result(res);


                std::string dir_path = "./error/"+ to_string(bar1.TradeDay) + "/bar";
                fs::create_directories(dir_path);
                string file_name = dir_path + "/" +bar1.StockID+"_"+to_string(bar1.TradeDay)+"_"+bar1.Exchange+"_m"+to_string(bar1.timeframe);
                toCsv(file_name+".csv", barData);
                
                ofstream outFile(file_name+".txt");
                if (outFile.is_open())
                {
                    outFile << sql_cmd.c_str();
                    outFile.close();
                    cerr<< "Write error SQL to file: " <<file_name<<".txt"<<endl;
                } 
                else {
                    cerr<< "Failed to open error SQL file: " << file_name << ".txt"<<endl;
                }

                return -1;
            }
            taos_free_result(res);

            // auto end=chrono::high_resolution_clock::now();
            // auto duration=chrono::duration_cast<chrono::milliseconds>(end-start);
            // cout<< BATCH_SIZE <<" Bars 上传耗时: "<<duration.count()<<"ms"<<endl;
        }
        auto upload_end = chrono::high_resolution_clock::now();
        auto upload_duration = chrono::duration_cast<chrono::milliseconds>(upload_end - upload_start);
        cout << barData.front().StockID<<"(bar"<<to_string(barData.front().timeframe)<<") "<<to_string(barData.size())<<" "<<upload_duration.count()<<"ms"<<endl;
        return 0;
    }

    

    // 删除表
    void drop_table(const string &database_name, const string &contract)
    {
        string sql_cmd = "drop table " + database_name + "." + contract;
        taos_query(conn, sql_cmd.c_str());
    }

    // 删除数据库
    void drop_database(const string &database_name)
    {
        string sql_cmd = "drop database if exists " + database_name;
        taos_query(conn, sql_cmd.c_str());
    }

    // 创建空表
    void CreateEmptyTable(const string &database_name, const string &table_name, const string &col_name)
    {
        string sql_cmd = "create table if not exists " + database_name + "." + table_name + " (ts timestamp, " + col_name + " float)";
        taos_query(conn, sql_cmd.c_str());
    }

    // 插入 CSV
    void insert_csv(const string &database_name, const string &table_name, const string &file_path)
    {
        string sql_cmd = "Insert into " + database_name + "." + table_name + " file '" + file_path + "'";
        taos_query(conn, sql_cmd.c_str());
    }


    // upload by files
    void upload_ticks_by_csv (const TickUploadConfig &tick_upload_config){
        string db_name;
        string col;
        if (tick_upload_config.transaction_type == "STOCK") {
            db_name = "txy_stock";
            stockTick tick;
            tick.Exchange = tick_upload_config.exchange;
            col = make_columns(tick);
        }else if (tick_upload_config.transaction_type == "ETF") {
            db_name = "txy_etf";
            etfTick tick;
            tick.Exchange = tick_upload_config.exchange;
            col = make_columns(tick);
        }else if (tick_upload_config.transaction_type == "LOF") {
            db_name = "txy_lof";
            etfTick tick;
            tick.Exchange = tick_upload_config.exchange;
            col = make_columns(tick);
        }else if (tick_upload_config.transaction_type == "INDEX") {
            db_name = "txy_index";
            indexTick tick;
            tick.Exchange = tick_upload_config.exchange;
            col = make_columns(tick);
        }else if (tick_upload_config.transaction_type == "BOND") {
            db_name = "txy_tb";
            bondTick tick;
            tick.Exchange = tick_upload_config.exchange;
            col = make_columns(tick);
        }
        string stockid = tick_upload_config.stockid;

        string sql = 
        "CREATE TABLE IF NOT EXISTS "+db_name+"."+stockid+" USING "+ db_name+".txy_tick" + " TAGS ('" + stockid + "');";

        
        TAOS_RES *res = taos_query(conn, sql.c_str());
        if (res == NULL || taos_errno(res) != 0)
        {
            cerr<< "Failed to create table, SQL: "<< sql << taos_errstr(res)<<endl;

            // throw runtime_error("Table creation failed: " + string(taos_errstr(conn)));
        }
        taos_free_result(res);


        sql = "INSERT INTO "+db_name+"."+stockid+" (" +  col + ") FILE " + "'" + tick_upload_config.file_path + "'";
        TAOS_RES *res2 = taos_query(conn, sql.c_str());
        if (res2 == NULL || taos_errno(res2) != 0)
        {
            cerr<< "Failed to upload file to table, SQL: "<<tick_upload_config.file_path<<" "<<taos_errstr(res2)<<endl;

            // throw runtime_error("CSV upload to table failed: " + string(taos_errstr(conn)));
        }

        // 释放资源
        taos_free_result(res2);
        // 删除文件 tick_upload_config.file_path
        // remove(tick_upload_config.file_path.c_str());
    }


    void upload_bars_by_csv(const BarUploadConfig &bar_upload_config){
        string db_name;
        string col;
        if (bar_upload_config.transaction_type == "STOCK") {
            db_name = "txy_stock";
            stockBar bar;
            bar.Exchange = bar_upload_config.exchange;
            col = make_columns(bar);
        }else if (bar_upload_config.transaction_type == "ETF") {
            db_name = "txy_etf";
            etfBar bar;
            bar.Exchange = bar_upload_config.exchange;
            col = make_columns(bar);
        }else if (bar_upload_config.transaction_type == "LOF") {
            db_name = "txy_lof";
            etfBar bar;
            bar.Exchange = bar_upload_config.exchange;
            col = make_columns(bar);
        }else if (bar_upload_config.transaction_type == "INDEX") {
            db_name = "txy_index";
            indexBar bar;
            bar.Exchange = bar_upload_config.exchange;
            col = make_columns(bar);
        }else if (bar_upload_config.transaction_type == "BOND") {
            db_name = "txy_tb";
            bondBar bar;
            bar.Exchange = bar_upload_config.exchange;
            col = make_columns(bar);
        }
        string stockid = bar_upload_config.stockid;

        string sql = 
        "CREATE TABLE IF NOT EXISTS "+db_name+"."+stockid+"_m"+to_string(bar_upload_config.timeframe)+" USING "+ db_name+".txy_bar" + " TAGS ('" + stockid + "', " + to_string(bar_upload_config.timeframe) + ");";

        TAOS_RES *res = taos_query(conn, sql.c_str());
        if (res == NULL || taos_errno(res) != 0)
        {
            cerr<< "Failed to create table, SQL: "+ sql +taos_errstr(res)<<endl;

            // throw runtime_error("Table creation failed: " + string(taos_errstr(conn)));
        }
        taos_free_result(res);


        sql = "INSERT INTO "+db_name+"."+stockid+"_m"+to_string(bar_upload_config.timeframe)+" (" +  col + ") FILE " + "'" + bar_upload_config.file_path + "'";
        
        TAOS_RES *res2 = taos_query(conn, sql.c_str());
        if (res2 == NULL || taos_errno(res2) != 0)
        {
            cerr<< "Failed to upload file to table, SQL: "+bar_upload_config.file_path+" "+taos_errstr(res2)<<endl;

            // throw runtime_error("CSV upload to table failed: " + string(taos_errstr(conn)));
        }

        // 释放资源
        taos_free_result(res2);

        // 删除文件 bar_upload_config.file_path
        // remove(bar_upload_config.file_path.c_str());
    }

};