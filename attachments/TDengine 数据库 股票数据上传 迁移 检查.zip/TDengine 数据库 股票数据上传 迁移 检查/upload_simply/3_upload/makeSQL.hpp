#pragma once

#include "../2_standardize/tick.hpp"
#include "../2_standardize/bar.hpp"

string make_table_name_index(){
    return 
    // baseTick
    "ts TIMESTAMP,"
    "TradingDay NCHAR(20),"
    "UpdateTime NCHAR(20),"
    "UpdateMillisec INT,"
    "Exchange NCHAR(10),"
    "StockID NCHAR(20),"
    "InstruStatus NCHAR(10),"

    "PreClosePrice DOUBLE,"
    "OpenPrice DOUBLE,"
    "HighPrice DOUBLE,"
    "LowPrice DOUBLE,"
    "LastPrice DOUBLE,"
    "Volume BIGINT,"
    "Turnover DOUBLE,"
    "TurnNum BIGINT";
}

string make_table_name_stock() {
    return 
    // baseTick
    "ts TIMESTAMP,"
    "TradingDay NCHAR(20),"
    "UpdateTime NCHAR(20),"
    "UpdateMillisec INT,"
    "Exchange NCHAR(10),"
    "StockID NCHAR(20),"
    "InstruStatus NCHAR(10),"

    "PreClosePrice DOUBLE,"
    "OpenPrice DOUBLE,"
    "HighPrice DOUBLE,"
    "LowPrice DOUBLE,"
    "LastPrice DOUBLE,"
    "Volume BIGINT,"
    "Turnover DOUBLE,"
    "TurnNum BIGINT,"

    // szUnique
    "PE DOUBLE,"

    // shLevel2Extra
    "AltWAvgBidPri DOUBLE,"
    "AltWAvgAskPri DOUBLE,"
    "WiDBuyNum INT,"
    "WiDBuyVol DOUBLE,"
    "WiDBuyMon DOUBLE,"
    "WiDSellNum INT,"
    "WiDSellVol DOUBLE,"
    "WiDSellMon DOUBLE,"
    "TotBidNum INT,"
    "TotSellNum INT,"     
    "MaxBidDur INT,"      
    "MaxSellDur INT,"   
    "BidNum INT,"
    "SellNum INT,"

    // level2Data
    "UpperLimitPrice DOUBLE,"
    "LowerLimitPrice DOUBLE,"
    "WeightedAvgBidPx DOUBLE,"
    "WeightedAvgOfferPx DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "AskPrice1 DOUBLE, AskVolume1 BIGINT, AskPrice2 DOUBLE, AskVolume2 BIGINT, AskPrice3 DOUBLE, AskVolume3 BIGINT, AskPrice4 DOUBLE, AskVolume4 BIGINT, AskPrice5 DOUBLE, AskVolume5 BIGINT, AskPrice6 DOUBLE, AskVolume6 BIGINT, AskPrice7 DOUBLE, AskVolume7 BIGINT, AskPrice8 DOUBLE, AskVolume8 BIGINT, AskPrice9 DOUBLE, AskVolume9 BIGINT, AskPrice10 DOUBLE, AskVolume10 BIGINT,"

    "BidPrice1 DOUBLE, BidVolume1 BIGINT, BidPrice2 DOUBLE, BidVolume2 BIGINT, BidPrice3 DOUBLE, BidVolume3 BIGINT, BidPrice4 DOUBLE, BidVolume4 BIGINT, BidPrice5 DOUBLE, BidVolume5 BIGINT, BidPrice6 DOUBLE, BidVolume6 BIGINT, BidPrice7 DOUBLE, BidVolume7 BIGINT, BidPrice8 DOUBLE, BidVolume8 BIGINT, BidPrice9 DOUBLE, BidVolume9 BIGINT, BidPrice10 DOUBLE, BidVolume10 BIGINT,"

    "NumOrdersB1 INT, NumOrdersB2 INT, NumOrdersB3 INT, NumOrdersB4 INT, NumOrdersB5 INT, NumOrdersB6 INT, NumOrdersB7 INT, NumOrdersB8 INT, NumOrdersB9 INT, NumOrdersB10 INT,"

    "NumOrdersS1 INT, NumOrdersS2 INT, NumOrdersS3 INT, NumOrdersS4 INT, NumOrdersS5 INT, NumOrdersS6 INT, NumOrdersS7 INT, NumOrdersS8 INT, NumOrdersS9 INT, NumOrdersS10 INT,"

    // szStatusField
    "TradingPhaseCode NCHAR(10)";
}

string make_table_name_etf(){
    return 
    // baseTick
    "ts TIMESTAMP,"
    "TradingDay NCHAR(20),"
    "UpdateTime NCHAR(20),"
    "UpdateMillisec INT,"
    "Exchange NCHAR(10),"
    "StockID NCHAR(20),"
    "InstruStatus NCHAR(10),"

    "PreClosePrice DOUBLE,"
    "OpenPrice DOUBLE,"
    "HighPrice DOUBLE,"
    "LowPrice DOUBLE,"
    "LastPrice DOUBLE,"
    "Volume BIGINT,"
    "Turnover DOUBLE,"
    "TurnNum BIGINT,"

    // etfUnique
    "IOPV DOUBLE,"
    "PreCloseIOPV DOUBLE,"              // 深交所：基金前收盘净值（IOPV）
    "EtfBuyNumber INT,"                 // 上交所：ETF 申购笔数
    "EtfBuyVolume DOUBLE,"              // 上交所：ETF 申购数量
    "EtfBuyMoney DOUBLE,"               // 上交所：ETF 申购金额
    "EtfSellNumber INT,"                // 上交所：ETF 赎回笔数
    "EtfSellVolume DOUBLE,"              // 上交所：ETF 赎回数量
    "ETFSellMoney DOUBLE,"               // 上交所：ETF 赎回金额

    // shLevel2Extra
    "AltWAvgBidPri DOUBLE,"
    "AltWAvgAskPri DOUBLE,"
    "WiDBuyNum INT,"
    "WiDBuyVol DOUBLE,"
    "WiDBuyMon DOUBLE,"
    "WiDSellNum INT,"
    "WiDSellVol DOUBLE,"
    "WiDSellMon DOUBLE,"
    "TotBidNum INT,"
    "TotSellNum INT,"     
    "MaxBidDur INT,"      
    "MaxSellDur INT,"   
    "BidNum INT,"
    "SellNum INT,"

    // level2Data
    "UpperLimitPrice DOUBLE,"
    "LowerLimitPrice DOUBLE,"
    "WeightedAvgBidPx DOUBLE,"
    "WeightedAvgOfferPx DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "AskPrice1 DOUBLE, AskVolume1 BIGINT, AskPrice2 DOUBLE, AskVolume2 BIGINT, AskPrice3 DOUBLE, AskVolume3 BIGINT, AskPrice4 DOUBLE, AskVolume4 BIGINT, AskPrice5 DOUBLE, AskVolume5 BIGINT, AskPrice6 DOUBLE, AskVolume6 BIGINT, AskPrice7 DOUBLE, AskVolume7 BIGINT, AskPrice8 DOUBLE, AskVolume8 BIGINT, AskPrice9 DOUBLE, AskVolume9 BIGINT, AskPrice10 DOUBLE, AskVolume10 BIGINT,"

    "BidPrice1 DOUBLE, BidVolume1 BIGINT, BidPrice2 DOUBLE, BidVolume2 BIGINT, BidPrice3 DOUBLE, BidVolume3 BIGINT, BidPrice4 DOUBLE, BidVolume4 BIGINT, BidPrice5 DOUBLE, BidVolume5 BIGINT, BidPrice6 DOUBLE, BidVolume6 BIGINT, BidPrice7 DOUBLE, BidVolume7 BIGINT, BidPrice8 DOUBLE, BidVolume8 BIGINT, BidPrice9 DOUBLE, BidVolume9 BIGINT, BidPrice10 DOUBLE, BidVolume10 BIGINT,"

    "NumOrdersB1 INT, NumOrdersB2 INT, NumOrdersB3 INT, NumOrdersB4 INT, NumOrdersB5 INT, NumOrdersB6 INT, NumOrdersB7 INT, NumOrdersB8 INT, NumOrdersB9 INT, NumOrdersB10 INT,"

    "NumOrdersS1 INT, NumOrdersS2 INT, NumOrdersS3 INT, NumOrdersS4 INT, NumOrdersS5 INT, NumOrdersS6 INT, NumOrdersS7 INT, NumOrdersS8 INT, NumOrdersS9 INT, NumOrdersS10 INT,"

    // szStatusField
    "TradingPhaseCode NCHAR(10)";
}

string make_table_name_bond() {
    return 
    // baseTick
    "ts TIMESTAMP,"
    "TradingDay NCHAR(20),"
    "UpdateTime NCHAR(20),"
    "UpdateMillisec INT,"
    "Exchange NCHAR(10),"
    "StockID NCHAR(20),"
    "InstruStatus NCHAR(10),"

    "PreClosePrice DOUBLE,"
    "OpenPrice DOUBLE,"
    "HighPrice DOUBLE,"
    "LowPrice DOUBLE,"
    "LastPrice DOUBLE,"
    "Volume BIGINT,"
    "Turnover DOUBLE,"
    "TurnNum BIGINT,"

    // shBondUnique
    "YieldToMatu DOUBLE,"

    // shLevel2Extra
    "AltWAvgBidPri DOUBLE,"
    "AltWAvgAskPri DOUBLE,"
    "WiDBuyNum INT,"
    "WiDBuyVol DOUBLE,"
    "WiDBuyMon DOUBLE,"
    "WiDSellNum INT,"
    "WiDSellVol DOUBLE,"
    "WiDSellMon DOUBLE,"
    "TotBidNum INT,"
    "TotSellNum INT,"     
    "MaxBidDur INT,"      
    "MaxSellDur INT,"   
    "BidNum INT,"
    "SellNum INT,"

    // level2Data
    "UpperLimitPrice DOUBLE,"
    "LowerLimitPrice DOUBLE,"
    "WeightedAvgBidPx DOUBLE,"
    "WeightedAvgOfferPx DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "AskPrice1 DOUBLE, AskVolume1 BIGINT, AskPrice2 DOUBLE, AskVolume2 BIGINT, AskPrice3 DOUBLE, AskVolume3 BIGINT, AskPrice4 DOUBLE, AskVolume4 BIGINT, AskPrice5 DOUBLE, AskVolume5 BIGINT, AskPrice6 DOUBLE, AskVolume6 BIGINT, AskPrice7 DOUBLE, AskVolume7 BIGINT, AskPrice8 DOUBLE, AskVolume8 BIGINT, AskPrice9 DOUBLE, AskVolume9 BIGINT, AskPrice10 DOUBLE, AskVolume10 BIGINT,"

    "BidPrice1 DOUBLE, BidVolume1 BIGINT, BidPrice2 DOUBLE, BidVolume2 BIGINT, BidPrice3 DOUBLE, BidVolume3 BIGINT, BidPrice4 DOUBLE, BidVolume4 BIGINT, BidPrice5 DOUBLE, BidVolume5 BIGINT, BidPrice6 DOUBLE, BidVolume6 BIGINT, BidPrice7 DOUBLE, BidVolume7 BIGINT, BidPrice8 DOUBLE, BidVolume8 BIGINT, BidPrice9 DOUBLE, BidVolume9 BIGINT, BidPrice10 DOUBLE, BidVolume10 BIGINT,"

    "NumOrdersB1 INT, NumOrdersB2 INT, NumOrdersB3 INT, NumOrdersB4 INT, NumOrdersB5 INT, NumOrdersB6 INT, NumOrdersB7 INT, NumOrdersB8 INT, NumOrdersB9 INT, NumOrdersB10 INT,"

    "NumOrdersS1 INT, NumOrdersS2 INT, NumOrdersS3 INT, NumOrdersS4 INT, NumOrdersS5 INT, NumOrdersS6 INT, NumOrdersS7 INT, NumOrdersS8 INT, NumOrdersS9 INT, NumOrdersS10 INT,"

    // szStatusField
    "TradingPhaseCode NCHAR(10)";
}

string make_table_name_baseBar(){
    return 
    // baseBar
    "ts timestamp, "
    "timeframe INT,"
    "StockID NCHAR(20),"
    "Exchange NCHAR(20),"
    "TradeDay INT,"
    "Open DOUBLE,"
    "High DOUBLE,"
    "Low DOUBLE,"
    "Close DOUBLE,"
    "Volume DOUBLE,"
    "Turnover DOUBLE,"
    "TurnNum BIGINT,"
    "PreClosePrice DOUBLE,"

    "OpenInstruStatus NCHAR(10),"
    "CloseInstruStatus NCHAR(10),"

    "Vwap DOUBLE";
;
}

string make_table_name_stockBar(){
    return 
    make_table_name_baseBar()+","+
    "ULimitPrice DOUBLE,"
    "LLimitPrice DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "OpenPE DOUBLE,"
    "ClosePE DOUBLE,"
    "HighPE DOUBLE,"
    "LowPE DOUBLE";
}

string make_table_name_etfBar(){
    return 
    make_table_name_baseBar()+","+
    "PreCloseIOPV DOUBLE,"

    "ULimitPrice DOUBLE,"
    "LLimitPrice DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "OpenIOPV DOUBLE,"
    "CloseIOPV DOUBLE,"
    "HighIOPV DOUBLE,"
    "LowIOPV DOUBLE,"
    "IOPVmaxDiffPos DOUBLE,"
    "IOPVmaxDiffNeg DOUBLE";

}

string make_table_name_bondBar(){
    return 
    make_table_name_baseBar()+","+
    "ULimitPrice DOUBLE,"
    "LLimitPrice DOUBLE,"
    "TotalBidQty BIGINT,"
    "TotalOfferQty BIGINT,"

    "YieldToMatu DOUBLE";
}
