#include <iostream>
#include <filesystem>
#include <chrono>
#include <ctime>
#include <iomanip>

#include "2_standardize/loadJson.h"
#include "2_standardize/tick.hpp"
#include "2_standardize/bar.hpp"
#include "2_standardize/mapping.hpp"
#include "2_standardize/standardizeTick.hpp"
#include "2_standardize/toCsv.hpp"
#include "2_standardize/makeBar.hpp"

#include "3_upload/taosManager.hpp"

namespace fs = std::filesystem;
using namespace std;

void print_time(const string &info){
     auto now = std::chrono::system_clock::now();
    
    // 获取 time_t 部分 (秒)
    std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);
    std::tm* local_tm = std::localtime(&now_time_t);

    // 获取毫秒部分
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()) % 1000;

    std::cout << std::put_time(local_tm, "%Y-%m-%d %H:%M:%S")
              << '.' << std::setfill('0') << std::setw(5) << ms.count()
              << ": "
              << info 
              << std::endl;
}

int main(int argc, char** argv) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    string data_config_path = "config/data_config.json";
    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <json_path>" << endl;
        // return 1;
    }else{
        data_config_path = argv[1];
    }

    data_config dc = data_config::load_config(data_config_path);

    unordered_map<string, string> dataMap;
    for (const auto& pair : fieldMap) {
        for (const auto& alt_name : pair.second) {
            dataMap[alt_name] = pair.first;
        }
    }

    unordered_map<string,vector<stockTick>> stockTickMap;
    unordered_map<string,vector<etfTick>> etfTickMap;
    unordered_map<string,vector<etfTick>> lofTickMap;
    unordered_map<string,vector<indexTick>> indexTickMap;
    unordered_map<string,vector<bondTick>> bondTickMap;

    print_time("开始阅读文件，标准化数据");


    LoadTick(
        dc.file_path,
        dataMap, 
        dc.chosen_stocks,
        dc.date,
        dc.exchange,
        stockTickMap,
        etfTickMap,
        lofTickMap,
        indexTickMap,
        bondTickMap,
        dc.loadstock,
        dc.loadetf,
        dc.loadindex,
        dc.loadbond
    );

    if (dc.debug){
        std::string dir_path = "debug/"+ dc.date + "/tick";
        fs::create_directories(dir_path);

        for (const auto & [key, value] : stockTickMap){
            toCsv(dir_path+"/"+key+".csv",value);
        }
        for (const auto & [key, value] : etfTickMap){
            toCsv(dir_path+"/"+key+".csv",value);
        }
        for (const auto & [key, value] : lofTickMap){
            toCsv(dir_path+"/"+key+".csv",value);
        }
        for (const auto & [key, value] : indexTickMap){
            toCsv(dir_path+"/"+key+".csv",value);
        }
        for (const auto & [key, value] : bondTickMap){
            toCsv(dir_path+"/"+key+".csv",value);
        }
    }

    unordered_map<string, unordered_map<int, vector<stockBar>>> stockBarMap;
    unordered_map<string, unordered_map<int, vector<etfBar>>> etfBarMap;
    unordered_map<string, unordered_map<int, vector<etfBar>>> lofBarMap;
    unordered_map<string, unordered_map<int, vector<indexBar>>> indexBarMap;
    unordered_map<string, unordered_map<int, vector<bondBar>>> bondBarMap;
    if (dc.loadbar){ 
        BarMakeManager bar_maker;
        if (!stockTickMap.empty()){
            stockBarMap = bar_maker.generateBarMap(stockTickMap, dc.bar_timeframes);
        }
        if (!etfTickMap.empty()){
            etfBarMap = bar_maker.generateBarMap(etfTickMap, dc.bar_timeframes);
        }
        if (!lofTickMap.empty()){
            lofBarMap = bar_maker.generateBarMap(lofTickMap, dc.bar_timeframes);
        }
        if (!indexTickMap.empty()){
            indexBarMap = bar_maker.generateBarMap(indexTickMap, dc.bar_timeframes);
        }
        if (!bondTickMap.empty()){
            bondBarMap = bar_maker.generateBarMap(bondTickMap, dc.bar_timeframes);
        }

        if (dc.debug){ 
            std::string dir_path = "debug/"+ dc.date + "/bar";
            fs::create_directories(dir_path);

            for (const auto & [key, tf_pair] : stockBarMap){
                for (const auto & [tf, value] : tf_pair){
                    toCsv(dir_path+"/"+key+"_"+std::to_string(tf)+".csv",value);
                }
            }
            for (const auto & [key, tf_pair] : etfBarMap){
                for (const auto & [tf, value] : tf_pair){
                    toCsv(dir_path+"/"+key+"_"+std::to_string(tf)+".csv",value);
                }
            }
            for (const auto & [key, tf_pair] : lofBarMap){
                for (const auto & [tf, value] : tf_pair){
                    toCsv(dir_path+"/"+key+"_"+std::to_string(tf)+".csv",value);
                }
            }
            for (const auto & [key, tf_pair] : indexBarMap){
                for (const auto & [tf, value] : tf_pair){
                    toCsv(dir_path+"/"+key+"_"+std::to_string(tf)+".csv",value);
                }
            }
            for (const auto & [key, tf_pair] : bondBarMap){
                for (const auto & [tf, value] : tf_pair){
                    toCsv(dir_path+"/"+key+"_"+std::to_string(tf)+".csv",value);
                }
            }
        
        }

    }

    string stock_num_info = 
    to_string(stockTickMap.size())+"(stock)\n"+
    to_string(etfTickMap.size())+"(etf)\n"+
    to_string(lofTickMap.size())+"(lof)\n"+
    to_string(indexTickMap.size())+"(index)\n"+
    to_string(bondTickMap.size())+"(tb)";
    
    print_time("数据标准化完成: \n"+stock_num_info);
    print_time("开始上传Tick和Bar数据");

    
    // 上传ticks和bars数据到taos数据库
    taos_config tc = taos_config::load_config("config/taos_config.json");
    TaosSQL taos(tc.host,tc.user,tc.password);

    // 建库和超级表
    taos.create_database("txy_stock");
    taos.create_tick_stable("txy_stock", "txy_tick", "STOCK");
    taos.create_bar_stable("txy_stock", "txy_bar", "STOCK");

    taos.create_database("txy_etf");
    taos.create_tick_stable("txy_etf", "txy_tick", "ETF");
    taos.create_bar_stable("txy_etf", "txy_bar", "ETF");

    // LOF haves the same struct as ETF's
    taos.create_database("txy_lof");
    taos.create_tick_stable("txy_lof", "txy_tick", "ETF");  
    taos.create_bar_stable("txy_lof", "txy_bar", "ETF");

    taos.create_database("txy_index");
    taos.create_tick_stable("txy_index", "txy_tick", "INDEX");
    taos.create_bar_stable("txy_index", "txy_bar", "INDEX");

    taos.create_database("txy_tb");
    taos.create_tick_stable("txy_tb", "txy_tick", "BOND");
    taos.create_bar_stable("txy_tb", "txy_bar", "BOND");

    // 上传ticks
    for (const auto & [key, value] : stockTickMap){
        if (!value.empty())
            taos.UpdateTick(value, "txy_stock");
    }
    for (const auto & [key, value] : etfTickMap){
        if (!value.empty())
            taos.UpdateTick(value, "txy_etf");
    }
    for (const auto & [key, value] : lofTickMap){
        if (!value.empty())
            taos.UpdateTick(value, "txy_lof");
    }
    for (const auto & [key, value] : indexTickMap){
        if (!value.empty())
            taos.UpdateTick(value, "txy_index");
    }
    for (const auto & [key, value] : bondTickMap){
        if (!value.empty())
            taos.UpdateTick(value, "txy_tb");
    }

    // 上传bars
    if(dc.loadbar){
        for (const auto & [key, tf_pair] : stockBarMap){
            for (const auto & [tf, value] : tf_pair){
                if (!value.empty()){
                    taos.UpdateBar(value, "txy_stock");
                }
            }
        }
        for (const auto & [key, tf_pair] : etfBarMap){
            for (const auto & [tf, value] : tf_pair){
                if (!value.empty()){
                    taos.UpdateBar(value, "txy_etf");
                }
            }
        }
        for (const auto & [key, tf_pair] : lofBarMap){
            for (const auto & [tf, value] : tf_pair){
                if (!value.empty()){
                    taos.UpdateBar(value, "txy_lof");
                }
            }
        }
        for (const auto & [key, tf_pair] : indexBarMap){
            for (const auto & [tf, value] : tf_pair){
                if (!value.empty()){
                    taos.UpdateBar(value, "txy_index");
                }
            }
        }
        for (const auto & [key, tf_pair] : bondBarMap){
            for (const auto & [tf, value] : tf_pair){
                if (!value.empty()){
                    taos.UpdateBar(value, "txy_tb");
                }
            }
        }
    }
    print_time("数据上传完成");

}
