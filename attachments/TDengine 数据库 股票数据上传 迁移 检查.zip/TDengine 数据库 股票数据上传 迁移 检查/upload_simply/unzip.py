import os
import shutil
import zipfile
import tarfile
import gzip
import argparse
import sys
import json
import shutil
from datetime import datetime

from tools import *


# 尝试导入第三方库，如果失败则设为 None 并在运行时检查
try:
    import rarfile
except ImportError:
    rarfile = None

try:
    import py7zr
except ImportError:
    py7zr = None


def cleanup(root_dir):
    # os.walk 遍历 root_path 及其所有子目录
    for dirpath, dirnames, filenames in os.walk(root_dir):
        for filename in filenames:
            shutil.move(os.path.join(dirpath,filename),os.path.join(root_dir,filename))
    # 删除空目录（除根目录外）
    for dirpath, dirnames, _ in os.walk(root_dir, topdown=False):
        if dirpath == root_dir:
            continue
        try:
            if not os.listdir(dirpath):
                os.rmdir(dirpath)
        except Exception:
            pass
    return True
def rename_target_file(root_path, target_name):
    """在 root_path 下寻找主要的 CSV 文件，并将其重命名为 target_name"""
    if not os.path.exists(root_path):
        return

    entries = os.listdir(root_path)
    csv_files = [f for f in entries if f.lower().endswith('.csv') and os.path.isfile(os.path.join(root_path, f))]
    
    if not csv_files:
        # 如果不是 csv 文件（比如用户解压的是其他格式），这里可以放宽限制或仅提示
        # 为了保持原逻辑，如果没有 csv 则跳过重命名，但保留文件
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        print_with_time(f"{timestamp}: {root_path} 下未找到 .csv 文件，跳过重命名步骤。当前文件列表：{entries}")
        return

    target_file = csv_files[0]
    
    if len(csv_files) > 1:
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        print_with_time(f"{timestamp}：发现多个 CSV 文件 {csv_files}，默认处理第一个：{target_file}")
    
    src_path = os.path.join(root_path, target_file)
    dst_path = os.path.join(root_path, target_name)
    
    if src_path != dst_path:
        if os.path.exists(dst_path):
            os.remove(dst_path)
        shutil.move(src_path, dst_path)
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        # print_with_time(f"{timestamp}: 文件已重命名：{target_file} -> {target_name}")
    else:
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        # print_with_time(f"{timestamp}: 文件名已是目标名称，无需修改")

def unzip_file(file_path, standard_name, target_path, unzip_password=None):
    if not os.path.exists(file_path):
        print_with_time(f"错误：文件不存在 {file_path}")
        return False

    # 确保目标路径存在
    if not os.path.exists(target_path):
        os.makedirs(target_path)

    _, ext = os.path.splitext(file_path)
    ext = ext.lower()
    basename = os.path.basename(file_path)
    tmp_path = os.path.join(target_path, 'temporary_save')
    os.makedirs(tmp_path,exist_ok=True)

    if ext == '.csv':
        shutil.copy2(file_path,os.path.join(tmp_path,basename))
        os.rename(os.path.join(tmp_path,basename),os.path.join(tmp_path,standard_name))
        # 重命名
        rename_target_file(tmp_path, standard_name)
        cleanup(target_path)
        return True

    # 处理复合扩展名
    basename_lower = os.path.basename(file_path).lower()
    if basename_lower.endswith('.tar.gz') or basename_lower.endswith('.tgz'):
        ext = '.tar.gz'
    elif basename_lower.endswith('.tar.bz2'):
        ext = '.tar.bz2'
    elif basename_lower.endswith('.tar.xz'):
        ext = '.tar.xz'
    # 显式处理 .gz (非 tar.gz)
    elif ext == '.gz':
        ext = '.gz'

    try:
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        print_with_time(f"{timestamp}: 开始解压：{os.path.basename(file_path)} ...")
        # 1. ZIP
        if ext == '.zip':
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                if unzip_password:
                    zip_ref.setpassword(unzip_password.encode('utf-8'))
                zip_ref.extractall(tmp_path)

        # 2. RAR
        elif ext == '.rar':
            if rarfile is None:
                raise ImportError("缺少 rarfile 库 (pip install rarfile)")
            with rarfile.RarFile(file_path, 'r') as rar_ref:
                rar_ref.extractall(path=tmp_path, pwd=unzip_password)

        # 3. 7Z
        elif ext == '.7z':
            if py7zr is None:
                raise ImportError("缺少 py7zr 库 (pip install py7zr)")
            with py7zr.SevenZipFile(file_path, mode='r', password=unzip_password) as seven_ref:
                seven_ref.extractall(path=tmp_path)

        # 4. TAR (包括 tar.gz, tar.bz2 等)
        elif ext in ['.tar', '.tar.gz', '.tgz', '.tar.bz2', '.tbz2', '.tar.xz', '.txz']:
            with tarfile.open(file_path, mode='r:*') as tar_ref:
                tar_ref.extractall(path=tmp_path)
        
        # 5. GZ (新增支持)
        elif ext == '.gz':
            # .gz 通常压缩的是单个文件
            input_filename = os.path.basename(file_path)
            # 推导输出文件名：去掉 .gz 后缀
            if input_filename.endswith('.gz'):
                output_filename = input_filename[:-3]
            else:
                output_filename = input_filename + '.out' # 以防万一
            
            output_filepath = os.path.join(tmp_path, output_filename)
            
            with gzip.open(file_path, 'rb') as f_in:
                with open(output_filepath, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            
        
        else:
            print_with_time(f"不支持的文件格式：{ext}")
            return False

        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        print_with_time(f"{timestamp}: 解压完成")
        
        # 扁平化 (对于 .gz 生成的单文件，此函数会快速检测并跳过)
        cleanup(tmp_path)
        
        # 重命名
        rename_target_file(tmp_path, standard_name)
        
        cleanup(target_path)
        
        
        # 尝试定位最终文件路径用于显示
        # final_files = [f for f in os.listdir(target_path) if os.path.isfile(os.path.join(target_path, f))]
        # if final_files:
        #     print_with_time(f"最终文件位置：{os.path.join(os.path.abspath(target_path), final_files[0])}")
        # else:
        #     print_with_time("警告：解压后目标目录为空。")
            
        return True

    except Exception as e:
        print_with_time(f"发生严重错误：{str(e)}")
        if "Bad password" in str(e) or "Incorrect password" in str(e) or "CRC" in str(e):
            print_with_time("提示：密码错误或文件损坏。")
        elif "unrar" in str(e).lower():
            print_with_time("提示：缺少 unrar 命令行工具。")
        return False

if __name__ == '__main__':
    # ================= 参数解析区域 =================
    parser = argparse.ArgumentParser(description='解压股票数据压缩包 (支持 zip, rar, 7z, tar, gz) 并标准化文件名')
    
    # 必填参数
    parser.add_argument('file_path', type=str, help='输入压缩文件的绝对或相对路径')
    
    # 可选参数
    parser.add_argument('-p', '--password', type=str, default=None, help='解压密码 (如果没有密码可不填，gz/tar 通常无密码)')
    parser.add_argument('-o', '--output', type=str, default='./tmp/', help='解压目标目录 (默认: ./tmp/)')
    parser.add_argument('-n', '--name', type=str, default='data.csv', help='期望的标准输出文件名 (默认: data.csv)')
    
    args = parser.parse_args()
    
    # 执行逻辑
    success = unzip_file(
        file_path=args.file_path,
        standard_name=args.name,
        target_path=args.output,
        unzip_password=args.password
    )
    
    # 根据执行结果返回退出码 (0成功, 1失败)，方便脚本调用
    sys.exit(0 if success else 1)