#pragma once

#include <unordered_map>
#include <string>
#include <vector>

using namespace std;

unordered_map<string, vector<string>> fieldMap = {
    {"ts",{"ts","timestamp"}},
    {"TradingDay",{"TradingDay","TradeDay"}},
    {"UpdateTime",{"UpdateTime","DataTimeStamp"}},
    {"UpdateMillisec",{"UpdateMillisec"}},
    {"StockID",{"SecurityID","StockID"}},
    {"Exchange",{"Exchange"}},
    {"InstruStatus",{"InstruStatus"}},
    {"TradingPhaseCode",{"TradingPhaseCode","EndOfDayMaker"}},

    {"PreClosePrice",{"PreCloPrice","PreClosePrice","PreClosePx"}},// yesterday close price
    {"OpenPrice",{"OpenPrice","OpenPx"}},
    {"HighPrice",{"HighPrice","HighPx"}},
    {"LowPrice",{"LowPrice","LowPx"}},
    {"LastPrice",{"LastPrice","LastPx"}},
    {"ClosePrice",{"ClosePrice"}},  // Today close price
    {"Volume",{"Volume","TradVolume","TotalumeTrade"}},
    {"Turnover",{"Turnover","TotalValueTrade"}},
    {"TurnNum",{"TurnNum","TradNumber","NumTrades"}},

    {"PE",{"PE","PE1","PERatio1"}},

    {"IOPV",{"IOPV"}},

    {"PreCloseIOPV",{"PreCloIOPV","PreCloseIOPV"}},
    {"EtfBuyNumber",{"EtfBuyNumber"}},
    {"EtfBuyVolume",{"EtfBuyVolume"}},
    {"EtfBuyMoney",{"EtfBuyMoney"}},
    {"EtfSellNumber",{"EtfSellNumber"}},
    {"EtfSellVolume",{"EtfSellVolume"}},
    {"ETFSellMoney",{"ETFSellMoney"}},

    {"YieldToMatu",{"YieldToMatu"}},
    {"TotWarExNum",{"TotWarExNum"}},

    {"AltWAvgBidPri",{"AltWAvgBidPri"}},
    {"AltWAvgAskPri",{"AltWAvgAskPri"}},
    {"WiDBuyNum",{"WiDBuyNum"}},
    {"WiDBuyVol",{"WiDBuyVol"}},
    {"WiDBuyMon",{"WiDBuyMon"}},
    {"WiDSellNum",{"WiDSellNum"}},
    {"WiDSellVol",{"WiDSellVol"}},
    {"WiDSellMon",{"WiDSellMon"}},
    {"TotBidNum",{"TotBidNum"}},
    {"TotSellNum",{"TotSellNum"}},
    {"MaxBidDur",{"MaxBidDur"}},
    {"MaxSellDur",{"MaxSellDur"}},
    {"BidNum",{"BidNum"}},
    {"SellNum",{"SellNum"}},

    {"UpperLimitPrice",{"UpperLimitPrice","WarUpperPri","HighLimitPrice"}},
    {"LowerLimitPrice",{"LowerLimitPrice","WarLowerPri","LowLimitPrice"}},
    {"WeightedAvgBidPx",{"WeightedAvgBidPx","WAvgBidPri"}},
    {"WeightedAvgOfferPx",{"WeightedAvgOfferPx","WAvgAskPri"}},
    {"TotalBidQty",{"TotalBidQty","TotalBidVol"}},
    {"TotalOfferQty",{"TotalOfferQty","TotalAskVol"}},

    {"AskPrice",{"AskPrice"}},
    {"AskVolume",{"AskVolume"}},
    {"BidPrice",{"BidPrice"}},
    {"BidVolume",{"BidVolume"}},

    // {"NumOrdersBid",{"NumOrdersBid"}},
    // {"NumOrdersAsk",{"NumOrdersAsk"}},
};
