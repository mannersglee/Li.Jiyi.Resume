#pragma once

#include <unordered_map>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>
#include <ctime>
#include <chrono>
#include <stdexcept>
#include <unordered_set>
#include <iomanip>
#include <cmath>
#include <cmath> 
#include <limits> 

#include "tick.hpp"
#include "mapping.hpp"
#include "encoding.hpp"

using namespace std;

bool isZero(double x, double epsilon = numeric_limits<double>::epsilon()){
    return abs(x) <= epsilon;
}

vector<string> SplitString(const string &input, const char &delimiter){
    vector<string> result;
    istringstream stream(input);
    string token;
    while (getline(stream, token, delimiter))
    {
        result.push_back(token);
    }
    return result;
}

double mystod(const string& s){
    if (s.length()!=0) return stod(s);
    else return 0.0;
}

int64_t mystoll(const string& s){
    if (s.length()==0) return 0;
    return stoll(s);
}

int32_t mystoi(const string& s){
    if (s.length()==0) return 0;
    return stoi(s);
}

string CHECK_STRING(const string& s){
    if (s.empty()) {
        return "NULL";
    }
    if (all_of(s.begin(), s.end(), [](unsigned char ch){ return isspace(ch); })) {
        return "NULL";
    }
    return s;
}

uint64_t extract_hms_time(const string& updateTime){
    vector<string> parts = SplitString(updateTime,':');
    string numStr = parts[0] + parts[1] + SplitString(parts[2],'.')[0];
    return stoull(numStr);
}

string extract_hms_time_str(const string& updateTime){
    vector<string> parts = SplitString(updateTime,':');
    string hms_time_str = parts[0] + parts[1] + SplitString(parts[2],'.')[0];
    if (parts[0].length() == 1) {
        hms_time_str = "0" + hms_time_str;
    }
    return hms_time_str;
}


bool LoadTick(
    const string &file_path, 
    const unordered_map<string, string>& dataMap, 
    const vector<string> &tick_vector,
    const string &ymd_date, 
    const string &exchange, 
    unordered_map<string,vector<stockTick>> &stockTickMap, 
    unordered_map<string,vector<etfTick>> &etfTickMap, 
    unordered_map<string,vector<etfTick>> &lofTickMap, 
    unordered_map<string,vector<indexTick>> &indexTickMap, 
    unordered_map<string,vector<bondTick>> &bondTickMap,
    const bool &LoadSTOCK,
    const bool &LoadETF,
    const bool &LoadINDEX,
    const bool &LoadBOND
)
{
    auto start = chrono::high_resolution_clock::now();

    ifstream infile(file_path);
    if (!infile.is_open()) {
        cerr << "Failed to open file: " << file_path;
        return false;
    }

    string header;
    getline(infile, header);
    vector<string> columns = SplitString(header, ',');
    for (size_t i = 0; i < columns.size(); ++i) {
        columns[i] = dataMap.count(columns[i]) ? dataMap.at(columns[i]) : columns[i];
    }
    unordered_map<string, int> columnIndexMap;
    for (size_t i = 0; i < columns.size(); ++i) {
        columnIndexMap[columns[i]] = i;
    }

    // >>> 移出循环：预计算 bgn_map <<<
    unordered_map<string, string> bgn_map;
    if (exchange == "SHSE") {
        bgn_map = make_enconding(sh_encoding_map);
    } else if (exchange == "SZSE") {
        bgn_map = make_enconding(sz_encoding_map);
    } else {
        cerr << "Unsupported exchange: " << exchange;
        return false;
    }

    bool choosepart = !tick_vector.empty();
    size_t invalid_num = 0;
    size_t total_num = 0;

    // 预计算 ymd_date 的数值部分（假设格式为 "YYYYMMDD"）
    uint64_t ymd_num = stoull(ymd_date); // 安全，因调用方保证格式

    while(infile.peek() != EOF) {
        string line;
        getline(infile, line);
        total_num++;

        vector<string> values = SplitString(line, ',');

        string stock_id = values[columnIndexMap["StockID"]];
        if (stock_id.size() < 6) {
            stock_id = string(6 - stock_id.size(), '0') + stock_id;
        }

        if (choosepart && find(tick_vector.begin(), tick_vector.end(), "S" + stock_id) == tick_vector.end()) {
            continue;
        }

        string updateTime = SplitString(values[columnIndexMap["UpdateTime"]],'.')[0];
        uint64_t hms_time = extract_hms_time(updateTime);
        if (hms_time < 91500 || hms_time > 151500)
            continue;

        string hms_str = extract_hms_time_str(updateTime);
        string timestamp_str=ymd_date+hms_str+"000";
        uint64_t tmptimestamp=stoull(timestamp_str);
        


        string transaction_type = judge_type(stock_id, bgn_map);
        bool to_process = (transaction_type == "TB" && LoadBOND) || (transaction_type == "STOCK" && LoadSTOCK) || (transaction_type == "INDEX" && LoadINDEX) || (transaction_type == "ETF" && LoadETF) || (transaction_type == "LOF" && LoadETF);
        if (!to_process) continue;
        else {
            baseTick basetick;
            szStatusField szstatusfield{};

            basetick.ts = tmptimestamp;
            basetick.TradingDay = ymd_date;
            basetick.UpdateTime = updateTime; // "HH:MM:SS"
            basetick.UpdateMillisec = 0;
            basetick.StockID = "S" + stock_id;
            basetick.Exchange = exchange;

            // InstruStatus 处理
            if (exchange == "SHSE") {
                string ins = CHECK_STRING(values[columnIndexMap["InstruStatus"]]);
                if (ins.find("START") != string::npos) basetick.InstruStatus = "START";
                else if (ins.find("OCALL") != string::npos) basetick.InstruStatus = "OCALL";
                else if (ins.find("TRADE") != string::npos) basetick.InstruStatus = "TRADE";
                else if (ins.find("SUSP") != string::npos) basetick.InstruStatus = "SUSP";
                else if (ins.find("CCALL") != string::npos) basetick.InstruStatus = "CCALL";
                else if (ins.find("CLOSE") != string::npos) basetick.InstruStatus = "CLOSE";
                else if (ins.find("ENDTR") != string::npos) basetick.InstruStatus = "ENDTR";
                else if (ins.find("HALT") != string::npos) basetick.InstruStatus = "HALT";
                else if (ins.find("ADD") != string::npos) basetick.InstruStatus = "ADD";
                else if (ins.find("BETW") != string::npos) basetick.InstruStatus = "BETW";
                else if (ins.find("BREAK") != string::npos) basetick.InstruStatus = "BREAK";
                else if (ins.find("DEL") != string::npos) basetick.InstruStatus = "DEL";
                else if (ins.find("FCALL") != string::npos) basetick.InstruStatus = "FCALL";
                else if (ins.find("ICALL") != string::npos) basetick.InstruStatus = "ICALL";
                else if (ins.find("IOBB") != string::npos) basetick.InstruStatus = "IOBB";
                else if (ins.find("IPOBB") != string::npos) basetick.InstruStatus = "IPOBB";
                else if (ins.find("OOBB") != string::npos) basetick.InstruStatus = "OOBB";
                else if (ins.find("OPOBB") != string::npos) basetick.InstruStatus = "OPOBB";
                else if (ins.find("NOTRD") != string::npos) basetick.InstruStatus = "NOTRD";
                else if (ins.find("POSTR") != string::npos) basetick.InstruStatus = "POSTR";
                else if (ins.find("PRETR") != string::npos) basetick.InstruStatus = "PRETR";
                else if (ins.find("VOLA") != string::npos) basetick.InstruStatus = "VOLA";
                else basetick.InstruStatus = "NULL";
            } else {
                string tpc = CHECK_STRING(values[columnIndexMap["TradingPhaseCode"]]);
                szstatusfield.TradingPhaseCode = tpc.substr(0, 2);
                const string& code = szstatusfield.TradingPhaseCode;
                if (code.find("1") != string::npos || code.find("N") != string::npos || code.find("n") != string::npos) {
                    basetick.InstruStatus = "ENDTR";
                    basetick.bar_flag = false;
                } 
                else if (code.find("S0") != string::npos) basetick.InstruStatus = "START";
                else if (code.find("O0") != string::npos) basetick.InstruStatus = "OCALL";
                else if (code.find("T0") != string::npos) basetick.InstruStatus = "TRADE";
                else if (code.find("B0") != string::npos) basetick.InstruStatus = "BREAK";
                else if (code.find("C0") != string::npos) basetick.InstruStatus = "CLOSE";
                else if (code.find("E0") != string::npos) basetick.InstruStatus = "ENDTR";
                else if (code.find("H0") != string::npos) basetick.InstruStatus = "HALT";
                else if (code.find("V0") != string::npos) basetick.InstruStatus = "VOLA";
                else basetick.InstruStatus = "NULL";

            }

            basetick.PreClosePrice = mystod(values[columnIndexMap["PreClosePrice"]]);
            basetick.OpenPrice = mystod(values[columnIndexMap["OpenPrice"]]);
            basetick.HighPrice = mystod(values[columnIndexMap["HighPrice"]]);
            basetick.LowPrice = mystod(values[columnIndexMap["LowPrice"]]);
            basetick.LastPrice = mystod(values[columnIndexMap["LastPrice"]]);
            basetick.Volume = mystoll(values[columnIndexMap["Volume"]]);
            basetick.Turnover = mystod(values[columnIndexMap["Turnover"]]);
            basetick.TurnNum = mystoll(values[columnIndexMap["TurnNum"]]);

            double closeprice = 0.0;
            if (columnIndexMap.count("ClosePrice")!=0)
                closeprice = mystod(values[columnIndexMap["ClosePrice"]]);
            else closeprice = 0;

            // if (basetick.InstruStatus=="TRADE" && (isZero(basetick.OpenPrice)|| isZero(basetick.HighPrice ) ||
            //     isZero(basetick.LowPrice)  || isZero(basetick.LastPrice))) {
            //     invalid_num++;
            //     continue;
            // }

            if (hms_time >= 91500 && hms_time < 93000) {
                basetick.bar_flag = false;
            } else {
                basetick.bar_flag = true; // 默认为 true
            }
           
            if (!isZero(closeprice)){
                basetick.LastPrice = closeprice;
            }

            // 初始化附加结构
            shLevel2Extra shlevel2extra{};
            level2Data level2data{};

            szUnique szunique{}; // STOCK unique: PE

            shBondUnique shbondunique{}; // YieldToMatu 到期收益率（债券核心指标）

            if (exchange == "SZSE") {
                szunique.PE = mystod(values[columnIndexMap["PE"]]);
                
            } else if (exchange == "SHSE") {
                shlevel2extra.AltWAvgBidPri = mystod(values[columnIndexMap["AltWAvgBidPri"]]);
                shlevel2extra.AltWAvgAskPri = mystod(values[columnIndexMap["AltWAvgAskPri"]]);
                shlevel2extra.WiDBuyNum = mystoi(values[columnIndexMap["WiDBuyNum"]]);
                shlevel2extra.WiDBuyVol = mystod(values[columnIndexMap["WiDBuyVol"]]);
                shlevel2extra.WiDBuyMon = mystod(values[columnIndexMap["WiDBuyMon"]]);
                shlevel2extra.WiDSellNum = mystoi(values[columnIndexMap["WiDSellNum"]]);
                shlevel2extra.WiDSellVol = mystod(values[columnIndexMap["WiDSellVol"]]);
                shlevel2extra.WiDSellMon = mystod(values[columnIndexMap["WiDSellMon"]]);

                shbondunique.YieldToMatu = mystod(values[columnIndexMap["YieldToMatu"]]);

            }

            level2data.UpperLimitPrice = mystod(values[columnIndexMap["UpperLimitPrice"]]);
            level2data.LowerLimitPrice = mystod(values[columnIndexMap["LowerLimitPrice"]]);
            level2data.WeightedAvgBidPx = mystod(values[columnIndexMap["WeightedAvgBidPx"]]);
            level2data.WeightedAvgOfferPx = mystod(values[columnIndexMap["WeightedAvgOfferPx"]]);
            level2data.TotalBidQty = mystoll(values[columnIndexMap["TotalBidQty"]]);
            level2data.TotalOfferQty = mystoll(values[columnIndexMap["TotalOfferQty"]]);

            for (int i = 0; i < 10; ++i) {
                string ask_price_key = "AskPrice" + to_string(i+1);
                string ask_volume_key = "AskVolume" + to_string(i+1);
                string bid_price_key = "BidPrice" + to_string(i+1);
                string bid_volume_key = "BidVolume" + to_string(i+1);
                string num_orders_ask_key = "NumOrdersS" + to_string(i+1);
                string num_orders_bid_key = "NumOrdersB" + to_string(i+1);

                level2data.AskPrices[i] = mystod(values[columnIndexMap[ask_price_key]]);
                level2data.AskVolumes[i] = mystoll(values[columnIndexMap[ask_volume_key]]);
                level2data.BidPrices[i] = mystod(values[columnIndexMap[bid_price_key]]);
                level2data.BidVolumes[i] = mystoll(values[columnIndexMap[bid_volume_key]]);
                if (columnIndexMap.count(num_orders_ask_key)!=0){
                    level2data.NumOrdersAsks[i] = mystoi(values[columnIndexMap[num_orders_ask_key]]);
                    level2data.NumOrdersBids[i] = mystoi(values[columnIndexMap[num_orders_bid_key]]);
                } else {
                    level2data.NumOrdersAsks[i] = 0;
                    level2data.NumOrdersBids[i] = 0;
                }
            }
            if (transaction_type == "INDEX" && LoadINDEX){
                indexTick tick(basetick);
                indexTickMap[basetick.StockID].push_back(tick);
            } else if (transaction_type == "STOCK" && LoadSTOCK){
                stockTick tick(basetick, szunique, shlevel2extra, level2data, szstatusfield);
                stockTickMap[basetick.StockID].push_back(tick);
            } else if (transaction_type == "TB" && LoadBOND) {
                bondTick tick(basetick,shbondunique,shlevel2extra,level2data,szstatusfield);
                bondTickMap[basetick.StockID].push_back(tick);
            } else if ((transaction_type == "ETF" || transaction_type == "LOF") && LoadETF) {
                etfUnique etfunique{};
                etfunique.IOPV = mystod(values[columnIndexMap["IOPV"]]);
                if (exchange == "SZSE") {
                    etfunique.PreCloseIOPV = mystod(values[columnIndexMap["PreCloseIOPV"]]);
                } else if (exchange == "SHSE") {
                    etfunique.EtfBuyNumber = mystoi(values[columnIndexMap["EtfBuyNumber"]]);
                    etfunique.EtfBuyVolume = mystod(values[columnIndexMap["EtfBuyVolume"]]);
                    etfunique.EtfBuyMoney = mystod(values[columnIndexMap["EtfBuyMoney"]]);
                    etfunique.EtfSellNumber = mystoi(values[columnIndexMap["EtfSellNumber"]]);
                    etfunique.EtfSellVolume = mystod(values[columnIndexMap["EtfSellVolume"]]);
                    etfunique.ETFSellMoney = mystod(values[columnIndexMap["ETFSellMoney"]]);
                }
                etfTick tick(basetick, etfunique, shlevel2extra, level2data, szstatusfield);
                if (transaction_type == "ETF")  etfTickMap[basetick.StockID].push_back(tick);
                else lofTickMap[basetick.StockID].push_back(tick);
            }
        }
    }

    infile.close();

    auto processTick = [&](auto& tickMap, uint64_t ambgnHHMMSS){
        for (auto& pair : tickMap) {
            auto& ticks = pair.second;
            if (ticks.size() < 2) continue;
            uint64_t ambgnts = ymd_num * 1000000000 + ambgnHHMMSS * 1000;
            uint64_t amendts = ymd_num * 1000000000 + 113000 * 1000;
            uint64_t pmbgnts = ymd_num * 1000000000 + 130000 * 1000;
            uint64_t pmendts = ymd_num * 1000000000 + 150000 * 1000;

            // auto validticks = ticks;
            // validticks.clear();

            auto validticks = std::decay_t<decltype(ticks)>{};

            for (size_t i=0;i<ticks.size()-1;i++){
                if (ticks[i].ts<ambgnts){
                    if (ticks[i+1].ts>ambgnts){
                        ticks[i].ts = ymd_num * 1000000000 + 93000 * 1000 + 1;
                        ticks[i].bar_flag = true;
                        
                    } else if (ticks[i+1].ts==ambgnts){
                        ticks[i].ts = ymd_num * 1000000000 + 93000 * 1000 + 1;
                        ticks[i+1].ts = ymd_num * 1000000000 + 93000 * 1000 + 2;
                        ticks[i].bar_flag = true;

                    }
                }

                if (ticks[i].ts<pmbgnts){
                    if (ticks[i+1].ts>pmbgnts){
                        ticks[i].ts = ymd_num * 1000000000 + 130000 * 1000 + 1;

                    } else if (ticks[i+1].ts==pmbgnts){
                        ticks[i].ts = ymd_num * 1000000000 + 130000 * 1000 + 1;
                        ticks[i+1].ts = ymd_num * 1000000000 + 130000 * 1000 + 2;
                    }
                }
            }

            for (size_t i = ticks.size()-1;i>0;i--){
                if (ticks[i].ts>amendts){
                    if (ticks[i-1].ts<amendts){
                        ticks[i].ts = ymd_num * 1000000000 + 112959 * 1000 + 999;
                    } else if (ticks[i-1].ts==amendts){
                        ticks[i-1].ts = ymd_num * 1000000000 + 112959 * 1000 + 998;
                        ticks[i].ts = ymd_num * 1000000000 + 112959 * 1000 + 999;
                    }
                }

                if (ticks[i].ts>pmendts){
                    if (ticks[i-1].ts<pmendts){
                        ticks[i].ts = ymd_num * 1000000000 + 145959 * 1000 + 999;
                    } else if (ticks[i-1].ts==pmendts){
                        ticks[i-1].ts = ymd_num * 1000000000 + 145959 * 1000 + 998;
                        ticks[i].ts = ymd_num * 1000000000 + 145959 * 1000 + 999;
                    }
                }
            }

            for (size_t i=0;i<ticks.size();i++){
                if ((ticks[i].ts >= ymd_num * 1000000000 + 91500 * 1000 && ticks[i].ts < ymd_num * 1000000000 + 93000 * 1000)){
                    ticks[i].bar_flag=false;
                    validticks.push_back(ticks[i]);
                }
                if (
                    (
                        (ticks[i].ts >= ymd_num * 1000000000 + 93000 * 1000 && ticks[i].ts < ymd_num * 1000000000 + 113000 * 1000) ||
                        (ticks[i].ts >= ymd_num * 1000000000 + 130000 * 1000 && ticks[i].ts < ymd_num * 1000000000 + 150000 * 1000)
                    ) &&
                    !isZero(ticks[i].OpenPrice) &&
                    !isZero(ticks[i].HighPrice) &&
                    !isZero(ticks[i].LowPrice) &&
                    !isZero(ticks[i].LastPrice) &&
                    ticks[i].Volume != 0
                ){
                    validticks.push_back(ticks[i]);
                }
            }

            ticks = validticks;
        }
    
    };
    
    if (!stockTickMap.empty()) {
        processTick(stockTickMap, 93000);
    }
    if (!etfTickMap.empty()) {
        processTick(etfTickMap, 93000);

    }
    if (!lofTickMap.empty()) {
        processTick(lofTickMap, 93000);
    }
    if (!indexTickMap.empty()){
        processTick(indexTickMap, 93000);

    }
    if (!bondTickMap.empty()) {
        processTick(bondTickMap, 93000);

    }

    if (invalid_num > 0) {
        cout << "Invalid lines: " << invalid_num << endl;
    }
    auto end = chrono::high_resolution_clock::now();
    auto duration = chrono::duration_cast<chrono::milliseconds>(end - start);
    if (total_num > 0) {
        // cout << "Average time spent reading per line: " << double(duration.count()) / total_num << setprecision(5) << " ms" << endl;
    } else {
        cout << "The file is empty or contains no valid data" << endl;
    }
    return true;
}

