#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <cstdint>

#include "tick.hpp"

using namespace std;

struct baseBar
{
    uint64_t ts = DEFAULT_TIMEFRAME; // YYYYmmddHHMMSS000 烛线时间
	int timeframe;              // K线周期

	string StockID; 
    string Exchange;
    int TradeDay;			    // 交易日

	double Open;			    // 开盘价
	double High;			    // 最高价
	double Low;			        // 最低价
	double Close;			    // 收盘价

	double Volume;		        // 成交量
	double Turnover;		    // 成交额
    int64_t TurnNum;            // 成交笔数
    double PreClosePrice;           // 昨日收盘价

    string OpenInstruStatus;    // 开盘价对应的深交所格式交易代码/状态
    string CloseInstruStatus;   // 收盘价对应的深交所格式交易代码/状态

    // 需要自己计算
    double Vwap;			    // VWAP
    baseBar() = default;
};

struct stockBar: public baseBar
{
    double ULimitPrice;	            // 涨停价
	double LLimitPrice;	            // 跌停价
    int64_t TotalBidQty;            // 总委买数量
    int64_t TotalOfferQty;          // 总委卖数量

    // 需要自己计算
    double OpenPE;                  // 深交所：开盘价对应的PE市盈率
    double ClosePE;                 // 深交所：收盘价对应的PE市盈率
    double HighPE;
    double LowPE;

    stockBar() = default;


};

struct etfBar: public baseBar{
    double PreCloseIOPV;            // 深交所：昨日基金前收盘净值（IOPV）

    double ULimitPrice;	            // 涨停价
	double LLimitPrice;	            // 跌停价
    int64_t TotalBidQty;            //总委买数量
    int64_t TotalOfferQty;          //总委卖数量

    // 需要自己计算
    double OpenIOPV;
    double HighIOPV;
    double CloseIOPV;
    double LowIOPV;
    double IOPVmaxDiffPos;          // Maximum positive IPOV difference between adjacent ticks
    double IOPVmaxDiffNeg;             // Maximum negtive IPOV difference between adjacent ticks


    etfBar() = default;

};

struct bondBar: public baseBar{

    double ULimitPrice;	            // 涨停价
	double LLimitPrice;	            // 跌停价
    int64_t TotalBidQty;            // 总委买数量
    int64_t TotalOfferQty;          // 总委卖数量

    double YieldToMatu;             // 上交所：到期收益率（债券）

};

struct indexBar: public baseBar{
    indexBar()=default;
};

string make_columns(const baseBar &bar) {
    return 
    "ts, timeframe, StockID, Exchange, TradeDay, Open, High, Low, Close, Volume, Turnover, TurnNum, Vwap, "
    "PreClosePrice,"
    "OpenInstruStatus, CloseInstruStatus";
}

void make_values(const baseBar &bar, ostringstream &sql_stream){
    sql_stream
    << "'" << ConvertToDateTimeString(bar.ts) << "',"
    << bar.timeframe << ","
    << "'" << bar.StockID << "',"
    << "'" << bar.Exchange << "',"
    << bar.TradeDay << ","
    << bar.Open << ","
    << bar.High << ","
    << bar.Low << ","
    << bar.Close << ","
    << bar.Volume << ","
    << bar.Turnover << ","
    << bar.TurnNum << ","
    << bar.Vwap << ",";

    sql_stream << bar.PreClosePrice << ",";
    sql_stream << "'" << bar.OpenInstruStatus << "',";
    sql_stream << "'" << bar.CloseInstruStatus << "'";

    return;
}

string make_columns(const indexBar &bar) {
    return 
    "ts, timeframe, StockID, Exchange, TradeDay, Open, High, Low, Close, Volume, Turnover, TurnNum, Vwap, "
    "PreClosePrice,"
    "OpenInstruStatus, CloseInstruStatus";
}

void make_values(const indexBar &bar, ostringstream &sql_stream){
    sql_stream
    << "'" << ConvertToDateTimeString(bar.ts) << "',"
    << bar.timeframe << ","
    << "'" << bar.StockID << "',"
    << "'" << bar.Exchange << "',"
    << bar.TradeDay << ","
    << bar.Open << ","
    << bar.High << ","
    << bar.Low << ","
    << bar.Close << ","
    << bar.Volume << ","
    << bar.Turnover << ","
    << bar.TurnNum << ","
    << bar.Vwap << ",";

    sql_stream << bar.PreClosePrice << ",";
    sql_stream << "'" << bar.OpenInstruStatus << "',";
    sql_stream << "'" << bar.CloseInstruStatus << "'";

    return;
}

string make_columns(const stockBar &bar) {
    string ret = 
    "ts, timeframe, StockID, Exchange, TradeDay, Open, High, Low, Close, Volume, Turnover, TurnNum, Vwap, "
    "PreClosePrice,"
    "OpenInstruStatus, CloseInstruStatus,"
    "ULimitPrice, LLimitPrice, TotalBidQty, TotalOfferQty";

    if (bar.Exchange=="SZSE")
        ret+=", OpenPE, ClosePE, HighPE, LowPE";

    return ret;
}

void make_values(const stockBar &bar, ostringstream &sql_stream){
    sql_stream
    << "'" << ConvertToDateTimeString(bar.ts) << "',"
    << bar.timeframe << ","
    << "'" << bar.StockID << "',"
    << "'" << bar.Exchange << "',"
    << bar.TradeDay << ","
    << bar.Open << ","
    << bar.High << ","
    << bar.Low << ","
    << bar.Close << ","
    << bar.Volume << ","
    << bar.Turnover << ","
    << bar.TurnNum << ","
    << bar.Vwap << ",";

    sql_stream << bar.PreClosePrice << ",";
    sql_stream << "'" << bar.OpenInstruStatus << "',";
    sql_stream << "'" << bar.CloseInstruStatus << "',";

    sql_stream
    << bar.ULimitPrice << ","
    << bar.LLimitPrice << ","
    << bar.TotalBidQty << ","
    << bar.TotalOfferQty;

    if (bar.Exchange=="SZSE")
        sql_stream << ","
        << bar.OpenPE << "," 
        << bar.ClosePE << "," 
        << bar.HighPE << "," 
        << bar.LowPE;

    return;
}

string make_columns(const etfBar &bar) {
    string ret = 
    "ts, timeframe, StockID, Exchange, TradeDay, Open, High, Low, Close, Volume, Turnover, TurnNum, Vwap, "
    "PreClosePrice,"
    "OpenInstruStatus, CloseInstruStatus,"
    "ULimitPrice, LLimitPrice, TotalBidQty, TotalOfferQty,"
    "OpenIOPV, CloseIOPV, HighIOPV, LowIOPV, IOPVmaxDiffPos, IOPVmaxDiffNeg";

    if (bar.Exchange=="SZSE")
        ret+=", PreCloseIOPV";

    return ret;
}

void make_values(const etfBar &bar, ostringstream &sql_stream){
    sql_stream
    << "'" << ConvertToDateTimeString(bar.ts) << "',"
    << bar.timeframe << ","
    << "'" << bar.StockID << "',"
    << "'" << bar.Exchange << "',"
    << bar.TradeDay << ","
    << bar.Open << ","
    << bar.High << ","
    << bar.Low << ","
    << bar.Close << ","
    << bar.Volume << ","
    << bar.Turnover << ","
    << bar.TurnNum << ","
    << bar.Vwap << ",";

    sql_stream << bar.PreClosePrice << ",";
    sql_stream << "'" << bar.OpenInstruStatus << "',";
    sql_stream << "'" << bar.CloseInstruStatus << "',";

    sql_stream
    << bar.ULimitPrice << ","
    << bar.LLimitPrice << ","
    << bar.TotalBidQty << ","
    << bar.TotalOfferQty << ","

    << bar.OpenIOPV << "," 
    << bar.CloseIOPV << "," 
    << bar.HighIOPV << "," 
    << bar.LowIOPV << "," 
    << bar.IOPVmaxDiffPos << ","
    << bar.IOPVmaxDiffNeg;

    if (bar.Exchange=="SZSE")
        sql_stream << ","
        << bar.PreCloseIOPV;

    return;
}


string make_columns(const bondBar &bar) {
    string ret = 
    "ts, timeframe, StockID, Exchange, TradeDay, Open, High, Low, Close, Volume, Turnover, TurnNum, Vwap, "
    "PreClosePrice,"
    "OpenInstruStatus, CloseInstruStatus,"
    "ULimitPrice, LLimitPrice, TotalBidQty, TotalOfferQty";

    if (bar.Exchange=="SHSE")
        ret+=", YieldToMatu";

    return ret;
}

void make_values(const bondBar &bar, ostringstream &sql_stream){
    sql_stream
    << "'" << ConvertToDateTimeString(bar.ts) << "',"
    << bar.timeframe << ","
    << "'" << bar.StockID << "',"
    << "'" << bar.Exchange << "',"
    << bar.TradeDay << ","
    << bar.Open << ","
    << bar.High << ","
    << bar.Low << ","
    << bar.Close << ","
    << bar.Volume << ","
    << bar.Turnover << ","
    << bar.TurnNum << ","
    << bar.Vwap << ",";

    sql_stream << bar.PreClosePrice << ",";
    sql_stream << "'" << bar.OpenInstruStatus << "',";
    sql_stream << "'" << bar.CloseInstruStatus << "',";

    sql_stream
    << bar.ULimitPrice << ","
    << bar.LLimitPrice << ","
    << bar.TotalBidQty << ","
    << bar.TotalOfferQty;

    if (bar.Exchange=="SHSE")
        sql_stream << ","
        << bar.YieldToMatu;

    return;
}

