#pragma once
#include "json.hpp"
#include <fstream>
#include <vector>
using json = nlohmann::json;

struct data_config {
    std::string file_path;
    std::string date;
    std::string exchange;
    std::vector<std::string> chosen_stocks;
    std::vector<int> bar_timeframes;

    bool loadstock, loadetf, loadindex, loadbond;
    bool loadbar;

    bool debug;
    data_config() : debug(false) {}

    static data_config load_config(const std::string& json_path) {
        std::ifstream file(json_path);
        
        if (!file.is_open()) {
            throw std::runtime_error("Error opening config file: " + json_path);
        }

        data_config config;
        json j;

        try {
            file >> j; 

            if (!j.contains("file_path")) throw std::runtime_error("Missing field: file_path");
            config.file_path = j["file_path"].get<std::string>();
            if (!j.contains("date")) throw std::runtime_error("Missing field: date");
            config.date = j["date"].get<std::string>();
            if (!j.contains("exchange")) throw std::runtime_error("Missing field: exchange");
            config.exchange = j["exchange"].get<std::string>();
            if (!j.contains("debug")) throw std::runtime_error("Missing field: debug");
            config.debug = j["debug"].get<bool>();

            if (!j.contains("loadstock")) throw std::runtime_error("Missing field: loadstock");
            config.loadstock = j["loadstock"].get<bool>();
            if (!j.contains("loadetf")) throw std::runtime_error("Missing field: loadetf");
            config.loadetf = j["loadetf"].get<bool>();
            if (!j.contains("loadindex")) throw std::runtime_error("Missing field: loadindex");
            config.loadindex = j["loadindex"].get<bool>();
            if (!j.contains("loadbond")) throw std::runtime_error("Missing field: loadbond");
            config.loadbond = j["loadbond"].get<bool>();

            if (!j.contains("loadbar")) throw std::runtime_error("Missing field: loadbar");
            config.loadbar = j["loadbar"].get<bool>();

            if (j.contains("chosen_stocks") && j["chosen_stocks"].is_array()) {
                config.chosen_stocks = j["chosen_stocks"].get<std::vector<std::string>>();
            } else {
                // 如果字段不存在或不是数组，设为空向量
                config.chosen_stocks = {}; 
                std::cerr << "Warning: 'chosen_stocks' not found or invalid, using empty list." << std::endl;
            }
            if (j.contains("bar_timeframes") && j["bar_timeframes"].is_array()) {
                config.bar_timeframes = j["bar_timeframes"].get<std::vector<int>>();
            } else {
                config.bar_timeframes = {5,15,30,1440}; 
                std::cerr << "Warning: 'bar_timeframes' not found or invalid, using empty list." << std::endl;
            }

        } catch (const json::parse_error& e) {
            throw std::runtime_error(std::string("JSON parse error: ") + e.what());
        } catch (const json::type_error& e) {
            throw std::runtime_error(std::string("JSON type error: ") + e.what());
        }

        return config;
    }
};

struct taos_config {
    std::string host;
    int port;
    std::string user;
    std::string password;
    taos_config() : port(6030) {}
    static taos_config load_config(const std::string& json_path) {
        std::ifstream file(json_path);
        
        if (!file.is_open()) {
            throw std::runtime_error("Error opening TAOS config file: " + json_path);
        }

        taos_config config;
        json j;

        try {
            file >> j;
            
            if (!j.contains("host")) throw std::runtime_error("Missing field: host");
            config.host = j["host"].get<std::string>();
            if (!j.contains("port")) throw std::runtime_error("Missing field: port");
            config.port = j["port"].get<int>();
            if (!j.contains("user")) throw std::runtime_error("Missing field: user");
            config.user = j["user"].get<std::string>();
            if (!j.contains("password")) throw std::runtime_error("Missing field: password");
            config.password = j["password"].get<std::string>();

        } catch (const json::parse_error& e) {
            throw std::runtime_error("JSON parse error in TAOS config: " + std::string(e.what()));
        } catch (const json::type_error& e) {
            throw std::runtime_error("JSON type error in TAOS config (e.g., port is not an integer): " + std::string(e.what()));
        } catch (const json::out_of_range& e) {
            throw std::runtime_error("JSON out of range error: " + std::string(e.what()));
        }
        return config;
    }
};
