#pragma once
#include <fstream>

#include "tick.hpp"
#include "bar.hpp"

template <typename T>
bool toCsv(const string &file_name, const vector<T> &tickorbars, const bool &having_header = true){
    std::ofstream file(file_name);
    if (!file.is_open()) {
        std::cerr << "无法打开文件: " << file_name << std::endl;
        return false;
    }

    if (having_header){
        // 写入表头 (Header)
        string header = make_columns(tickorbars[0]);
        file << header << "\n";
    }
   
    // 写入每一行数据
    for (const auto& item : tickorbars) {
        ostringstream value_stream;
        make_values(item, value_stream);
        file << value_stream.str() << "\n"; // 利用重载的 << 运算符
    }

    file.close();
    return true;
}

