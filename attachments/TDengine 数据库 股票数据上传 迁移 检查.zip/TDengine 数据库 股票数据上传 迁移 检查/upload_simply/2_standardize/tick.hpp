#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <cstdint>
#include <sstream>
#include <iomanip>

using namespace std;

#define DEFAULT_TIMEFRAME 19700101000000000ULL

// =============== 基础通用字段（所有证券共用） ===============
struct baseTick
{
    uint64_t ts = DEFAULT_TIMEFRAME;                     // 统一时间戳 (YYYYmmddHHMMSSmmm)
    string TradingDay;              // 交易日（"YYYYMMDD"）
    string UpdateTime;              // 交易所原始更新时间（HHMMSS）
    int32_t UpdateMillisec;         // 毫秒部分
    string StockID;                 // 证券代码
    string Exchange;                // "SH" 或 "SZ"
    string InstruStatus;            // 标准化交易阶段（SH 原生，SZ 转换而来）

    double PreClosePrice;           // 昨收
    double OpenPrice;               // 开盘
    double HighPrice;            // 最高
    double LowPrice;             // 最低
    double LastPrice;               // 最新价
    int64_t Volume;                 // 成交量
    double Turnover;                // 成交金额
    int64_t TurnNum;                // 成交笔数

    bool bar_flag = true;       // 是否用于生成K线
};

// =============== 上交所原始状态字段 ===============
struct shStatusField
{
    string InstruStatus;            // SH 原始交易状态
};

// =============== 深交所债券补充状态 ===============
struct szStatusField
{
    string TradingPhaseCode;            // SZ 原始交易状态
};

// =============== 深交所特有字段（主要为股票） ===============
struct szUnique
{
    double PE;                      // 深交所：市盈率（主要用于股票）
};

// =============== 上交所 Level-2 补充字段 ===============
struct shLevel2Extra
{
    double AltWAvgBidPri;           // 加权平均委买价
    double AltWAvgAskPri;           // 加权平均委卖价
    int32_t WiDBuyNum;              // 加权买入笔数（WDBuyNumber）
    double WiDBuyVol;               // 加权买入数量（WDBuyAmount）
    double WiDBuyMon;               // 加权买入金额（WDBuyMoney）
    int32_t WiDSellNum;
    double WiDSellVol;
    double WiDSellMon;
    int32_t TotBidNum;              // 总买入委托笔数
    int32_t TotSellNum;
    int32_t MaxBidDur;              // 买方最大等待时间
    int32_t MaxSellDur;
    int32_t BidNum;                 // 最优买盘笔数
    int32_t SellNum;                // 最优卖盘笔数

};

// =============== 深度行情（10档，通用） ===============
struct level2Data
{
    double UpperLimitPrice;         // 涨停价（债券也有涨跌幅限制）
    double LowerLimitPrice;         // 跌停价

    double WeightedAvgBidPx;        // 加权平均委买价（WAvgPx 通常指成交均价，此处为委托均价）
    double WeightedAvgOfferPx;      // 加权平均委卖价
    int64_t TotalBidQty;            // 总委买量
    int64_t TotalOfferQty;          // 总委卖量

    vector<double> AskPrices  = vector<double>(10, 0.0);
    vector<int64_t> AskVolumes = vector<int64_t>(10, 0);
    vector<double> BidPrices  = vector<double>(10, 0.0);
    vector<int64_t> BidVolumes = vector<int64_t>(10, 0);

    vector<int32_t> NumOrdersBids = vector<int32_t>(10, 0);
    vector<int32_t> NumOrdersAsks = vector<int32_t>(10, 0);
};

// =============== ETF 特有字段（含 SH 申购赎回 + SZ IOPV） ===============
struct etfUnique
{
    double IOPV;
    double PreCloseIOPV;            // 深交所：基金前收盘净值（IOPV）
    int32_t EtfBuyNumber;           // 上交所：ETF 申购笔数
    double EtfBuyVolume;            // 上交所：ETF 申购数量
    double EtfBuyMoney;             // 上交所：ETF 申购金额
    int32_t EtfSellNumber;          // 上交所：ETF 赎回笔数
    double EtfSellVolume;           // 上交所：ETF 赎回数量
    double ETFSellMoney;            // 上交所：ETF 赎回金额
};

// =============== 债券/权证特有字段 ===============
struct shBondUnique
{
    double YieldToMatu;             // 上交所：到期收益率（债券）
};

// =============== 指数 Tick 结构 ===============
struct indexTick : public baseTick
{
    // 默认构造
    indexTick() = default;

    // 构造函数（便于从基础字段构建）
    indexTick(const baseTick &bt)
    {
        this->ts = bt.ts;
        this->TradingDay = bt.TradingDay;
        this->UpdateTime = bt.UpdateTime;
        this->UpdateMillisec = bt.UpdateMillisec;
        this->StockID = bt.StockID;
        this->Exchange = bt.Exchange;
        this->InstruStatus = bt.InstruStatus;

        this->PreClosePrice = bt.PreClosePrice;
        this->OpenPrice = bt.OpenPrice;
        this->HighPrice = bt.HighPrice;
        this->LowPrice = bt.LowPrice;
        this->LastPrice = bt.LastPrice;
        this->Volume = bt.Volume;
        this->Turnover = bt.Turnover;
        this->TurnNum = bt.TurnNum;

        this->bar_flag = bt.bar_flag;

    }
};

// =============== 股票 Tick 结构 ===============
struct stockTick : public baseTick,
                   public szUnique,             // PE
                   public shLevel2Extra,        // SH Level-2 统计
                   public level2Data,
                   public szStatusField
{
    stockTick() = default;
    stockTick(const baseTick &bt, const szUnique &su, const shLevel2Extra &sle, const level2Data &ld, const szStatusField &ssf)
    {
        this->ts = bt.ts;
        this->TradingDay = bt.TradingDay;
        this->UpdateTime = bt.UpdateTime;
        this->UpdateMillisec = bt.UpdateMillisec;
        this->StockID = bt.StockID;
        this->Exchange = bt.Exchange;
        this->InstruStatus = bt.InstruStatus;

        this->PreClosePrice = bt.PreClosePrice;
        this->OpenPrice = bt.OpenPrice;
        this->HighPrice = bt.HighPrice;
        this->LowPrice = bt.LowPrice;
        this->LastPrice = bt.LastPrice;
        this->Volume = bt.Volume;
        this->Turnover = bt.Turnover;
        this->TurnNum = bt.TurnNum;

        this->PE = su.PE;

        this->AltWAvgBidPri = sle.AltWAvgBidPri;
        this->AltWAvgAskPri = sle.AltWAvgAskPri;
        this->WiDBuyNum = sle.WiDBuyNum;
        this->WiDBuyVol = sle.WiDBuyVol;
        this->WiDBuyMon = sle.WiDBuyMon;
        this->WiDSellNum = sle.WiDSellNum;
        this->WiDSellVol = sle.WiDSellVol;
        this->WiDSellMon = sle.WiDSellMon;
        this->TotBidNum = sle.TotBidNum;
        this->TotSellNum = sle.TotSellNum;
        this->MaxBidDur = sle.MaxBidDur;
        this->MaxSellDur = sle.MaxSellDur;
        this->BidNum = sle.BidNum;
        this->SellNum = sle.SellNum;

        this->UpperLimitPrice = ld.UpperLimitPrice;
        this->LowerLimitPrice = ld.LowerLimitPrice;
        this->WeightedAvgBidPx = ld.WeightedAvgBidPx;
        this->WeightedAvgOfferPx = ld.WeightedAvgOfferPx;
        this->TotalBidQty = ld.TotalBidQty;
        this->TotalOfferQty = ld.TotalOfferQty;
        this->AskPrices = ld.AskPrices;
        this->AskVolumes = ld.AskVolumes;
        this->BidPrices = ld.BidPrices;
        this->BidVolumes = ld.BidVolumes;
        this->NumOrdersBids = ld.NumOrdersBids;
        this->NumOrdersAsks = ld.NumOrdersAsks;
        this->TradingPhaseCode = ssf.TradingPhaseCode;
    }

};

// =============== ETF Tick 结构 ===============
struct etfTick : public baseTick,
                 public etfUnique,          // ETF 申购赎回 + IOPV
                 public shLevel2Extra,      // SH 也有 Level-2 字段
                 public level2Data,
                 public szStatusField
{
    etfTick() = default;
    etfTick(const baseTick &bt,
            const etfUnique &eu,
            const shLevel2Extra &sle,
            const level2Data &ld,
            const szStatusField &ssf)
    {
        this->ts = bt.ts;
        this->TradingDay = bt.TradingDay;
        this->UpdateTime = bt.UpdateTime;
        this->UpdateMillisec = bt.UpdateMillisec;
        this->StockID = bt.StockID;
        this->Exchange = bt.Exchange;
        this->InstruStatus = bt.InstruStatus;

        this->PreClosePrice = bt.PreClosePrice;
        this->OpenPrice = bt.OpenPrice;
        this->HighPrice = bt.HighPrice;
        this->LowPrice = bt.LowPrice;
        this->LastPrice = bt.LastPrice;
        this->Volume = bt.Volume;
        this->Turnover = bt.Turnover;
        this->TurnNum = bt.TurnNum;

        this->IOPV = eu.IOPV;
        this->PreCloseIOPV = eu.PreCloseIOPV;
        this->EtfBuyNumber = eu.EtfBuyNumber;
        this->EtfBuyVolume = eu.EtfBuyVolume;
        this->EtfBuyMoney = eu.EtfBuyMoney;
        this->EtfSellNumber = eu.EtfSellNumber;
        this->EtfSellVolume = eu.EtfSellVolume;
        this->ETFSellMoney = eu.ETFSellMoney;

        this->AltWAvgBidPri = sle.AltWAvgBidPri;
        this->AltWAvgAskPri = sle.AltWAvgAskPri;
        this->WiDBuyNum = sle.WiDBuyNum;
        this->WiDBuyVol = sle.WiDBuyVol;
        this->WiDBuyMon = sle.WiDBuyMon;
        this->WiDSellNum = sle.WiDSellNum;
        this->WiDSellVol = sle.WiDSellVol;
        this->WiDSellMon = sle.WiDSellMon;
        this->TotBidNum = sle.TotBidNum;
        this->TotSellNum = sle.TotSellNum;
        this->MaxBidDur = sle.MaxBidDur;
        this->MaxSellDur = sle.MaxSellDur;
        this->BidNum = sle.BidNum;
        this->SellNum = sle.SellNum;

        this->UpperLimitPrice = ld.UpperLimitPrice;
        this->LowerLimitPrice = ld.LowerLimitPrice;
        this->WeightedAvgBidPx = ld.WeightedAvgBidPx;
        this->WeightedAvgOfferPx = ld.WeightedAvgOfferPx;
        this->TotalBidQty = ld.TotalBidQty;
        this->TotalOfferQty = ld.TotalOfferQty;
        this->AskPrices = ld.AskPrices;
        this->AskVolumes = ld.AskVolumes;
        this->BidPrices = ld.BidPrices;
        this->BidVolumes = ld.BidVolumes;
        this->NumOrdersBids = ld.NumOrdersBids;
        this->NumOrdersAsks = ld.NumOrdersAsks;
        this->TradingPhaseCode = ssf.TradingPhaseCode;
    }
};

// =============== 债券 Tick 定义 ===============
struct bondTick : public baseTick,
                  public shBondUnique,   // 到期收益率
                  public shLevel2Extra,  // SH Level-2 统计字段
                  public level2Data,
                  public szStatusField
{
    bondTick() = default;
    bondTick(const baseTick &bt, const shBondUnique &shb, const shLevel2Extra &sle, const level2Data &ld, const szStatusField &ssf)
    {
        this->ts = bt.ts;
        this->TradingDay = bt.TradingDay;
        this->UpdateTime = bt.UpdateTime;
        this->UpdateMillisec = bt.UpdateMillisec;
        this->StockID = bt.StockID;
        this->Exchange = bt.Exchange;
        this->InstruStatus = bt.InstruStatus;

        this->PreClosePrice = bt.PreClosePrice;
        this->OpenPrice = bt.OpenPrice;
        this->HighPrice = bt.HighPrice;
        this->LowPrice = bt.LowPrice;
        this->LastPrice = bt.LastPrice;
        this->Volume = bt.Volume;
        this->Turnover = bt.Turnover;
        this->TurnNum = bt.TurnNum;

        this->YieldToMatu = shb.YieldToMatu;

        this->AltWAvgBidPri = sle.AltWAvgBidPri;
        this->AltWAvgAskPri = sle.AltWAvgAskPri;
        this->WiDBuyNum = sle.WiDBuyNum;
        this->WiDBuyVol = sle.WiDBuyVol;
        this->WiDBuyMon = sle.WiDBuyMon;
        this->WiDSellNum = sle.WiDSellNum;
        this->WiDSellVol = sle.WiDSellVol;
        this->WiDSellMon = sle.WiDSellMon;
        this->TotBidNum = sle.TotBidNum;
        this->TotSellNum = sle.TotSellNum;
        this->MaxBidDur = sle.MaxBidDur;
        this->MaxSellDur = sle.MaxSellDur;
        this->BidNum = sle.BidNum;
        this->SellNum = sle.SellNum;

        this->UpperLimitPrice = ld.UpperLimitPrice;
        this->LowerLimitPrice = ld.LowerLimitPrice;
        this->WeightedAvgBidPx = ld.WeightedAvgBidPx;
        this->WeightedAvgOfferPx = ld.WeightedAvgOfferPx;
        this->TotalBidQty = ld.TotalBidQty;
        this->TotalOfferQty = ld.TotalOfferQty;
        this->AskPrices = ld.AskPrices;
        this->AskVolumes = ld.AskVolumes;
        this->BidPrices = ld.BidPrices;
        this->BidVolumes = ld.BidVolumes;
        this->NumOrdersBids = ld.NumOrdersBids;
        this->NumOrdersAsks = ld.NumOrdersAsks;
        this->TradingPhaseCode = ssf.TradingPhaseCode;
    }

};

// =============== 权证（Warrant）特有字段 ===============
struct warrantUnique
{
    double TotWarExNum;   // 上交所：权证行权总量
};

// =============== 权证 Tick 结构 ===============
struct warrantTick : public baseTick,
                     public warrantUnique,     // 权证核心特有字段
                     public shLevel2Extra,     // SH Level-2 统计
                     public level2Data,        // 10档深度
                     public szStatusField      // SZ 状态
{
};






string ConvertToDateTimeString(uint64_t longDateTime)
{
    // 将长整型转换为符号涛思上传格式的字符串datetime 比如20231216101503001为 "2023-12-16 10:15:03.001"
    int year, month, day, hour, minute, second, millisecond;

    // 提取各个部分的值
    millisecond = static_cast<int>(longDateTime % 1000);
    longDateTime /= 1000;
    second = static_cast<int>(longDateTime % 100);
    longDateTime /= 100;
    minute = static_cast<int>(longDateTime % 100);
    longDateTime /= 100;
    hour = static_cast<int>(longDateTime % 100);
    longDateTime /= 100;
    day = static_cast<int>(longDateTime % 100);
    longDateTime /= 100;
    month = static_cast<int>(longDateTime % 100);
    year = static_cast<int>(longDateTime / 100);

    // 使用 stringstream 构建日期时间字符串
    stringstream dateTimeStream;
    dateTimeStream.imbue(locale("C"));
    dateTimeStream << setfill('0')
                << setw(4) << year << "-"
                << setw(2) << month << "-"
                << setw(2) << day << " "
                << setw(2) << hour << ":"
                << setw(2) << minute << ":"
                << setw(2) << second << "."
                << setw(3) << millisecond;

    return dateTimeStream.str();
}


string make_columns(const stockTick& tick){
    string columns;
    columns = 
    // baseTick
    "ts,TradingDay,UpdateTime,UpdateMillisec,StockID,Exchange,InstruStatus,PreClosePrice,OpenPrice,HighPrice,LowPrice,LastPrice,Volume,Turnover,TurnNum,"

    // level2Data
    "UpperLimitPrice,LowerLimitPrice,WeightedAvgBidPx,WeightedAvgOfferPx,TotalBidQty,TotalOfferQty,"
    
    "AskPrice1,AskVolume1,AskPrice2,AskVolume2,AskPrice3,AskVolume3,AskPrice4,AskVolume4,AskPrice5,AskVolume5,AskPrice6,AskVolume6,AskPrice7,AskVolume7,AskPrice8,AskVolume8,AskPrice9,AskVolume9,AskPrice10,AskVolume10,"
    "BidPrice1,BidVolume1,BidPrice2,BidVolume2,BidPrice3,BidVolume3,BidPrice4,BidVolume4,BidPrice5,BidVolume5,BidPrice6,BidVolume6,BidPrice7,BidVolume7,BidPrice8,BidVolume8,BidPrice9,BidVolume9,BidPrice10,BidVolume10,"

    "NumOrdersB1, NumOrdersB2, NumOrdersB3, NumOrdersB4, NumOrdersB5, NumOrdersB6, NumOrdersB7, NumOrdersB8, NumOrdersB9, NumOrdersB10," 
    "NumOrdersS1, NumOrdersS2, NumOrdersS3, NumOrdersS4, NumOrdersS5, NumOrdersS6, NumOrdersS7, NumOrdersS8, NumOrdersS9, NumOrdersS10,";
    
    if (tick.Exchange == "SZSE"){
        // szUnique szStatusField
        columns += "PE, TradingPhaseCode";
    }else if (tick.Exchange == "SHSE"){
        // shLevel2Extra
        columns += "AltWAvgBidPri,AltWAvgAskPri,WiDBuyNum,WiDBuyVol,WiDBuyMon,WiDSellNum,WiDSellVol,WiDSellMon,TotBidNum,TotSellNum,MaxBidDur,MaxSellDur,BidNum,SellNum";
    }
    return columns;
}

void make_values(const stockTick &tick, ostringstream &sql_stream){
    sql_stream
    // baseTick
    << "'" << ConvertToDateTimeString(tick.ts) << "',"
    << "'" << tick.TradingDay << "',"
    << "'" << tick.UpdateTime << "',"
    << tick.UpdateMillisec << ","
    << "'" << tick.StockID << "',"
    << "'" << tick.Exchange << "',"
    << "'" << tick.InstruStatus << "',"
    << tick.PreClosePrice << ","
    << tick.OpenPrice << ","
    << tick.HighPrice << ","
    << tick.LowPrice << ","
    << tick.LastPrice << ","
    << tick.Volume << ","
    << tick.Turnover << ","
    << tick.TurnNum << ","
    // level2Data
    << tick.UpperLimitPrice << ","
    << tick.LowerLimitPrice << ","
    << tick.WeightedAvgBidPx << ","
    << tick.WeightedAvgOfferPx << ","
    << tick.TotalBidQty << ","
    << tick.TotalOfferQty << ",";

    // 10档买卖盘数据
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.AskPrices[i-1] << to_string(i) << "," << tick.AskVolumes[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.BidPrices[i-1] << to_string(i) << "," << tick.BidVolumes[i-1] << to_string(i) << ",";
    }
    
    // 10档申买卖数量
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersBids[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersAsks[i-1] << to_string(i) << ",";
    }

    if (tick.Exchange == "SZSE") {
        sql_stream 
        << tick.PE << ","
        << "'" << tick.TradingPhaseCode << "'";

    } else if (tick.Exchange == "SHSE") {
        sql_stream 
        << tick.AltWAvgBidPri << ","
        << tick.AltWAvgAskPri << ","
        << tick.WiDBuyNum << ","
        << tick.WiDBuyVol << ","
        << tick.WiDBuyMon << ","
        << tick.WiDSellNum << ","
        << tick.WiDSellVol << ","
        << tick.WiDSellMon << ","
        << tick.TotBidNum << ","
        << tick.TotSellNum << ","
        << tick.MaxBidDur << ","
        << tick.MaxSellDur << ","
        << tick.BidNum << ","
        << tick.SellNum;
    }
}

string make_columns(const etfTick &tick){
    string columns;
    columns = 
    // baseTick
    "ts,TradingDay,UpdateTime,UpdateMillisec,StockID,Exchange,InstruStatus,PreClosePrice,OpenPrice,HighPrice,LowPrice,LastPrice,Volume,Turnover,TurnNum,"

    // level2Data
    "UpperLimitPrice,LowerLimitPrice,WeightedAvgBidPx,WeightedAvgOfferPx,TotalBidQty,TotalOfferQty,"
    
    "AskPrice1,AskVolume1,AskPrice2,AskVolume2,AskPrice3,AskVolume3,AskPrice4,AskVolume4,AskPrice5,AskVolume5,AskPrice6,AskVolume6,AskPrice7,AskVolume7,AskPrice8,AskVolume8,AskPrice9,AskVolume9,AskPrice10,AskVolume10,"
    "BidPrice1,BidVolume1,BidPrice2,BidVolume2,BidPrice3,BidVolume3,BidPrice4,BidVolume4,BidPrice5,BidVolume5,BidPrice6,BidVolume6,BidPrice7,BidVolume7,BidPrice8,BidVolume8,BidPrice9,BidVolume9,BidPrice10,BidVolume10,"

    "NumOrdersB1, NumOrdersB2, NumOrdersB3, NumOrdersB4, NumOrdersB5, NumOrdersB6, NumOrdersB7, NumOrdersB8, NumOrdersB9, NumOrdersB10," 
    "NumOrdersS1, NumOrdersS2, NumOrdersS3, NumOrdersS4, NumOrdersS5, NumOrdersS6, NumOrdersS7, NumOrdersS8, NumOrdersS9, NumOrdersS10,"

    "IOPV,";

    if (tick.Exchange == "SZSE"){
        // etfUnique's szuique, szStatusField
        columns += "PreCloseIOPV, TradingPhaseCode";
    }else if (tick.Exchange == "SHSE"){
        // etfUnique's shunique
        columns += "EtfBuyNumber,EtfBuyVolume,EtfBuyMoney,EtfSellNumber,EtfSellVolume,ETFSellMoney,";
        // shLevel2Extra
        columns += "AltWAvgBidPri,AltWAvgAskPri,WiDBuyNum,WiDBuyVol,WiDBuyMon,WiDSellNum,WiDSellVol,WiDSellMon,TotBidNum,TotSellNum,MaxBidDur,MaxSellDur,BidNum,SellNum";
    }
    return columns;
}


void make_values(const etfTick &tick, ostringstream &sql_stream){
    sql_stream
    // baseTick
    << "'" << ConvertToDateTimeString(tick.ts) << "',"
    << "'" << tick.TradingDay << "',"
    << "'" << tick.UpdateTime << "',"
    << tick.UpdateMillisec << ","
    << "'" << tick.StockID << "',"
    << "'" << tick.Exchange << "',"
    << "'" << tick.InstruStatus << "',"
    << tick.PreClosePrice << ","
    << tick.OpenPrice << ","
    << tick.HighPrice << ","
    << tick.LowPrice << ","
    << tick.LastPrice << ","
    << tick.Volume << ","
    << tick.Turnover << ","
    << tick.TurnNum << ","
    // level2Data
    << tick.UpperLimitPrice << ","
    << tick.LowerLimitPrice << ","
    << tick.WeightedAvgBidPx << ","
    << tick.WeightedAvgOfferPx << ","
    << tick.TotalBidQty << ","
    << tick.TotalOfferQty << ",";

    // 10档买卖盘数据
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.AskPrices[i-1] << to_string(i) << "," << tick.AskVolumes[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.BidPrices[i-1] << to_string(i) << "," << tick.BidVolumes[i-1] << to_string(i) << ",";
    }
    
    // 10档申买卖数量
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersBids[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersAsks[i-1] << to_string(i) << ",";
    }

    sql_stream << tick.IOPV << ",";

    if (tick.Exchange == "SZSE") {
        sql_stream 
        << tick.PreCloseIOPV << ","
        << "'" << tick.TradingPhaseCode << "'";

    } else if (tick.Exchange == "SHSE") {
        sql_stream 
        // etfUnique's shunique
        << tick.EtfBuyNumber << ","
        << tick.EtfBuyVolume << ","
        << tick.EtfBuyMoney << ","
        << tick.EtfSellNumber << ","
        << tick.EtfSellVolume << ","
        << tick.ETFSellMoney << ","
        // shLevel2Extra
        << tick.AltWAvgBidPri << ","
        << tick.AltWAvgAskPri << ","
        << tick.WiDBuyNum << ","
        << tick.WiDBuyVol << ","
        << tick.WiDBuyMon << ","
        << tick.WiDSellNum << ","
        << tick.WiDSellVol << ","
        << tick.WiDSellMon << ","
        << tick.TotBidNum << ","
        << tick.TotSellNum << ","
        << tick.MaxBidDur << ","
        << tick.MaxSellDur << ","
        << tick.BidNum << ","
        << tick.SellNum;
    }
}


string make_columns(const indexTick& tick){
    string columns;
    columns = 
    // baseTick
    "ts,TradingDay,UpdateTime,UpdateMillisec,StockID,Exchange,InstruStatus,PreClosePrice,OpenPrice,HighPrice,LowPrice,LastPrice,Volume,Turnover,TurnNum";

    return columns;
}

void make_values(const indexTick &tick, ostringstream &sql_stream){
    sql_stream
    // baseTick
    << "'" << ConvertToDateTimeString(tick.ts) << "',"
    << "'" << tick.TradingDay << "',"
    << "'" << tick.UpdateTime << "',"
    << tick.UpdateMillisec << ","
    << "'" << tick.StockID << "',"
    << "'" << tick.Exchange << "',"
    << "'" << tick.InstruStatus << "',"
    << tick.PreClosePrice << ","
    << tick.OpenPrice << ","
    << tick.HighPrice << ","
    << tick.LowPrice << ","
    << tick.LastPrice << ","
    << tick.Volume << ","
    << tick.Turnover << ","
    << tick.TurnNum;

}


string make_columns(const bondTick& tick){
    string columns;
    columns = 
    // baseTick
    "ts,TradingDay,UpdateTime,UpdateMillisec,StockID,Exchange,InstruStatus,PreClosePrice,OpenPrice,HighPrice,LowPrice,LastPrice,Volume,Turnover,TurnNum,"

    // level2Data
    "UpperLimitPrice,LowerLimitPrice,WeightedAvgBidPx,WeightedAvgOfferPx,TotalBidQty,TotalOfferQty,"
    
    "AskPrice1,AskVolume1,AskPrice2,AskVolume2,AskPrice3,AskVolume3,AskPrice4,AskVolume4,AskPrice5,AskVolume5,AskPrice6,AskVolume6,AskPrice7,AskVolume7,AskPrice8,AskVolume8,AskPrice9,AskVolume9,AskPrice10,AskVolume10,"
    "BidPrice1,BidVolume1,BidPrice2,BidVolume2,BidPrice3,BidVolume3,BidPrice4,BidVolume4,BidPrice5,BidVolume5,BidPrice6,BidVolume6,BidPrice7,BidVolume7,BidPrice8,BidVolume8,BidPrice9,BidVolume9,BidPrice10,BidVolume10,"

    "NumOrdersB1, NumOrdersB2, NumOrdersB3, NumOrdersB4, NumOrdersB5, NumOrdersB6, NumOrdersB7, NumOrdersB8, NumOrdersB9, NumOrdersB10," 
    "NumOrdersS1, NumOrdersS2, NumOrdersS3, NumOrdersS4, NumOrdersS5, NumOrdersS6, NumOrdersS7, NumOrdersS8, NumOrdersS9, NumOrdersS10,";
    
    if (tick.Exchange == "SZSE"){
        // szUnique szStatusField
        columns += "TradingPhaseCode";
    }else if (tick.Exchange == "SHSE"){
        // shLevel2Extra
        columns += "YieldToMatu,AltWAvgBidPri,AltWAvgAskPri,WiDBuyNum,WiDBuyVol,WiDBuyMon,WiDSellNum,WiDSellVol,WiDSellMon,TotBidNum,TotSellNum,MaxBidDur,MaxSellDur,BidNum,SellNum";
    }
    return columns;
}

void make_values(const bondTick &tick, ostringstream &sql_stream){
    sql_stream
    // baseTick
    << "'" << ConvertToDateTimeString(tick.ts) << "',"
    << "'" << tick.TradingDay << "',"
    << "'" << tick.UpdateTime << "',"
    << tick.UpdateMillisec << ","
    << "'" << tick.StockID << "',"
    << "'" << tick.Exchange << "',"
    << "'" << tick.InstruStatus << "',"
    << tick.PreClosePrice << ","
    << tick.OpenPrice << ","
    << tick.HighPrice << ","
    << tick.LowPrice << ","
    << tick.LastPrice << ","
    << tick.Volume << ","
    << tick.Turnover << ","
    << tick.TurnNum << ","
    // level2Data
    << tick.UpperLimitPrice << ","
    << tick.LowerLimitPrice << ","
    << tick.WeightedAvgBidPx << ","
    << tick.WeightedAvgOfferPx << ","
    << tick.TotalBidQty << ","
    << tick.TotalOfferQty << ",";

    // 10档买卖盘数据
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.AskPrices[i-1] << to_string(i) << "," << tick.AskVolumes[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.BidPrices[i-1] << to_string(i) << "," << tick.BidVolumes[i-1] << to_string(i) << ",";
    }
    
    // 10档申买卖数量
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersBids[i-1] << to_string(i) << ",";
    }
    for (size_t i=1;i<=10;i++){
        sql_stream << tick.NumOrdersAsks[i-1] << to_string(i) << ",";
    }

    if (tick.Exchange == "SZSE") {
        sql_stream << "'" << tick.TradingPhaseCode << "'";

    } else if (tick.Exchange == "SHSE") {
        sql_stream 
        << tick.YieldToMatu << ","
        << tick.AltWAvgBidPri << ","
        << tick.AltWAvgAskPri << ","
        << tick.WiDBuyNum << ","
        << tick.WiDBuyVol << ","
        << tick.WiDBuyMon << ","
        << tick.WiDSellNum << ","
        << tick.WiDSellVol << ","
        << tick.WiDSellMon << ","
        << tick.TotBidNum << ","
        << tick.TotSellNum << ","
        << tick.MaxBidDur << ","
        << tick.MaxSellDur << ","
        << tick.BidNum << ","
        << tick.SellNum;
    }
}




