#include <algorithm>
#include <cmath>
#include <unordered_map>
#include <string.h>

#include "tick.hpp"
#include "bar.hpp"
#include "standardizeTick.hpp"

using namespace std;

class BarMakeManager { 
public:
    double getticksize(stockTick &tick){
        return 0.01;
    }

    double getticksize(indexTick &tick){
        return 0.01;
    }

    double getticksize(bondTick &tick){
        return 0.01;
    }

    double getticksize(etfTick &tick){
        return 0.001;
    }

    double NormalizePrice(double price, double ticksize){
        return round(price / ticksize) * ticksize;
    }

    int GetMinute(uint64_t int_datetime)
    {
        int length = to_string(int_datetime).length();
        uint64_t divisor = (length == 14) ? 100 : 100000;
        return (int_datetime / divisor) % 100;
    }

    uint64_t GetTickBarLabel(uint64_t timestamp, int timeframe)
    {
        uint64_t stamp = static_cast<uint64_t>(floor(timestamp / 100000)); // get the time stamp
        int minute = GetMinute(timestamp);
        stamp = (stamp - minute % timeframe) * 100000;
        return stamp;
    }

    bool TwoTickSameBar(uint64_t t1, uint64_t t2, int timeframe)
    {
        uint64_t s1 = GetTickBarLabel(t1, timeframe);
        uint64_t s2 = GetTickBarLabel(t2, timeframe);
        return s1 == s2;
    }

    indexBar BuildBar(vector<indexTick> &ticks, const int timeframe, const indexTick &pretick, const bool isorder) {
        if (ticks.empty()) return indexBar();        

        if  (!isorder) {
            sort(ticks.begin(), ticks.end(),
                [](const indexTick& a, const indexTick& b) {
                    return a.ts < b.ts;  // 升序
                });
        }

        // 验证输入数据是否在一个 timeframe 内
        // ts: YYYYMMDDHHMMSSMMM
        if (!ticks.empty()) {
            if (ticks[ticks.size() - 1].ts - ticks[0].ts > timeframe * 100000) {
                cerr << "数据时间间隔超出 timeframe" << endl;
                return indexBar();
            }
        }

        indexBar bar;
        bar.timeframe = timeframe;
        bar.StockID = ticks[0].StockID;
        bar.Exchange = ticks[0].Exchange;

        bar.ts = GetTickBarLabel(ticks[0].ts, timeframe);
        bar.Close = ticks[ticks.size() - 1].LastPrice;
        bar.Open = ticks[0].LastPrice;
        bar.High = ticks[0].LastPrice; // 后面会遍历更新
        bar.Low = ticks[0].LastPrice;
        bar.TradeDay = stoll(ticks[0].TradingDay);

        double VWap = 0;
        if (pretick.ts == DEFAULT_TIMEFRAME) {
            bar.Volume = ticks[ticks.size() - 1].Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum;
            VWap += ticks[0].Volume * ticks[0].LastPrice;
        } else {
            bar.Volume = ticks[ticks.size() - 1].Volume - pretick.Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover - pretick.Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum - pretick.TurnNum;
            VWap += (ticks[0].Volume - pretick.Volume)*ticks[0].LastPrice;
        }

        double ticksize = getticksize(ticks[0]);

        for (int i = 1; i < ticks.size(); i++)
        {
            auto pretick = ticks.at(i - 1);
            auto tick = ticks.at(i);
            double p = tick.LastPrice;
            if (p > bar.High){
                bar.High = p;
            }
            if (p < bar.Low) {
                bar.Low = p;
            }
            VWap += (tick.Volume - pretick.Volume) * tick.LastPrice;
        }
        if (bar.Volume > 0)
        {
            bar.Vwap = NormalizePrice(VWap / bar.Volume, ticksize);
        }
        else
        {
            bar.Vwap = bar.Close;
        }

        bar.PreClosePrice = ticks[0].PreClosePrice;

        bar.OpenInstruStatus = ticks[0].InstruStatus;
        bar.CloseInstruStatus = ticks[ticks.size() - 1].InstruStatus;

        if (ticks[0].ts == DEFAULT_TIMEFRAME)
            cerr << "UNKNOWN ERROR IN BUILD BAR" << endl;

        return bar;
    }

    stockBar BuildBar(vector<stockTick> &ticks, const int timeframe, const stockTick &pretick, const bool isorder) { 
        if (ticks.empty()) return stockBar();        
        if  (!isorder) {
            sort(ticks.begin(), ticks.end(),
                [](const stockTick& a, const stockTick& b) {
                    return a.ts < b.ts;  // 升序
                });
        }

        // 验证输入数据是否在一个 timeframe 内
        // ts: YYYYMMDDHHMMSSMMM
        if (!ticks.empty()) {
            if (ticks[ticks.size() - 1].ts - ticks[0].ts > timeframe * 100000) {
                cerr << "数据时间间隔超出 timeframe" << endl;
                return stockBar();
            }
        }

        stockBar bar;
        bar.timeframe = timeframe;
        bar.StockID = ticks[0].StockID;
        bar.Exchange = ticks[0].Exchange;

        bar.ts = GetTickBarLabel(ticks[0].ts, timeframe);
        bar.Close = ticks[ticks.size() - 1].LastPrice;
        bar.Open = ticks[0].LastPrice;
        bar.High = ticks[0].LastPrice; // 后面会遍历更新
        bar.Low = ticks[0].LastPrice;
        bar.OpenPE = ticks[0].PE;
        bar.ClosePE = ticks[ticks.size() - 1].PE;
        bar.HighPE = ticks[0].PE;
        bar.LowPE = ticks[0].PE;
        bar.ULimitPrice = ticks[0].UpperLimitPrice;
        bar.LLimitPrice = ticks[0].LowerLimitPrice;
        bar.TradeDay = stoll(ticks[0].TradingDay);
        bar.TotalBidQty = ticks[0].TotalBidQty;
        bar.TotalOfferQty = ticks[0].TotalOfferQty;

        double VWap = 0;
        if (pretick.ts == DEFAULT_TIMEFRAME) {
            bar.Volume = ticks[ticks.size() - 1].Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum;
            
            VWap += ticks[0].Volume * ticks[0].LastPrice;
        } else {
            bar.Volume = ticks[ticks.size() - 1].Volume - pretick.Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover - pretick.Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum - pretick.TurnNum;
            VWap += (ticks[0].Volume - pretick.Volume)*ticks[0].LastPrice;
        }

        double ticksize = getticksize(ticks[0]);

        for (int i = 1; i < ticks.size(); i++)
        {
            auto pretick = ticks.at(i - 1);
            auto tick = ticks.at(i);
            bar.TotalBidQty += tick.TotalBidQty;
            bar.TotalOfferQty += tick.TotalOfferQty;
            double p = tick.LastPrice;
            if (p > bar.High){
                bar.High = p;

            }
            if (p < bar.Low) {
                bar.Low = p;
            }
            
            VWap += (tick.Volume - pretick.Volume) * tick.LastPrice;

            if (tick.Exchange == "SHSE") continue;

            if (tick.PE > bar.HighPE) {
                bar.HighPE = tick.PE;
            }
            if (tick.PE < bar.LowPE) {
                bar.LowPE = tick.PE;
            }
        }
        if (bar.Volume > 0)
        {
            bar.Vwap = NormalizePrice(VWap / bar.Volume, ticksize);
        }
        else
        {
            bar.Vwap = bar.Close;
        }

        bar.PreClosePrice = ticks[0].PreClosePrice;

        bar.OpenInstruStatus = ticks[0].InstruStatus;
        bar.CloseInstruStatus = ticks[ticks.size() - 1].InstruStatus;

        if (ticks[0].Exchange == "SHSE") {
            bar.OpenPE = bar.ClosePE = bar.HighPE = bar.LowPE = 0.0;
        }

        if (ticks[0].ts == DEFAULT_TIMEFRAME)
            cerr << "UNKNOWN ERROR IN BUILD BAR" << endl;

        return bar;
    }

    etfBar BuildBar(vector<etfTick> &ticks, const int timeframe, const etfTick &pretick, const bool isorder) { 
        if (ticks.empty()) return etfBar();
        if  (!isorder) {
            sort(ticks.begin(), ticks.end(),
                [](const etfTick& a, const etfTick& b) {
                    return a.ts < b.ts;  // 升序
                });
        }

        // 验证输入数据是否在一个 timeframe 内
        // ts: YYYYMMDDHHMMSSMMM
        if (!ticks.empty()) {
            if (ticks[ticks.size() - 1].ts - ticks[0].ts > timeframe * 100000) {
                cerr << "数据时间间隔超出 timeframe" << endl;
                return etfBar();
            }
        }

        etfBar bar; 
        bar.timeframe = timeframe;
        bar.StockID = ticks[0].StockID;
        bar.Exchange = ticks[0].Exchange;

        bar.ts = GetTickBarLabel(ticks[0].ts, timeframe);
        bar.Close = ticks[ticks.size() - 1].LastPrice;
        bar.Open = ticks[0].LastPrice;
        bar.High = ticks[0].LastPrice; // 后面会遍历更新
        bar.Low = ticks[0].LastPrice;

        bar.OpenIOPV = ticks[0].IOPV;
        bar.CloseIOPV = ticks[ticks.size() - 1].IOPV;
        bar.HighIOPV = ticks[0].IOPV;
        bar.LowIOPV = ticks[0].IOPV;

        bar.ULimitPrice = ticks[0].UpperLimitPrice;
        bar.LLimitPrice = ticks[0].LowerLimitPrice;
        bar.TradeDay = stoll(ticks[0].TradingDay);

        bar.TotalBidQty = ticks[0].TotalBidQty;
        bar.TotalOfferQty = ticks[0].TotalOfferQty;

        double VWap = 0;
        if (pretick.ts == DEFAULT_TIMEFRAME) {
            bar.Volume = ticks[ticks.size() - 1].Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum;
    
            VWap += ticks[0].Volume * ticks[0].LastPrice;
        } else {
            bar.Volume = ticks[ticks.size() - 1].Volume - pretick.Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover - pretick.Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum - pretick.TurnNum;
            VWap += (ticks[0].Volume - pretick.Volume)*ticks[0].LastPrice;
        }

        double ticksize = getticksize(ticks[0]);

        double IOPVmaxDiffPos = 0;
        double IOPVmaxDiffNeg = 0;


        for (int i = 1; i < ticks.size(); i++)
        {
            auto pretick = ticks.at(i - 1);
            auto tick = ticks.at(i);
            if (tick.IOPV > pretick.IOPV){
                if (tick.IOPV - pretick.IOPV > IOPVmaxDiffPos)
                    IOPVmaxDiffPos = tick.IOPV - pretick.IOPV;
            } else {
                if (tick.IOPV - pretick.IOPV < IOPVmaxDiffNeg)
                    IOPVmaxDiffNeg = tick.IOPV - pretick.IOPV;
            }
            bar.TotalBidQty += tick.TotalBidQty;
            bar.TotalOfferQty += tick.TotalOfferQty;
            double p = tick.LastPrice;
            if (p > bar.High){
                bar.High = p;
            }
            if (p < bar.Low) {
                bar.Low = p;
            }
            if (tick.IOPV > bar.HighIOPV) {
                bar.HighIOPV = tick.IOPV;
            }
            if (tick.IOPV < bar.LowIOPV) {
                bar.LowIOPV = tick.IOPV;
            }
            VWap += (tick.Volume - pretick.Volume) * tick.LastPrice;
        }
        if (bar.Volume > 0)
        {
            bar.Vwap = NormalizePrice(VWap / bar.Volume, ticksize);
        }
        else
        {
            bar.Vwap = bar.Close;
        }

        bar.IOPVmaxDiffPos = IOPVmaxDiffPos;
        bar.IOPVmaxDiffNeg = IOPVmaxDiffNeg;
        bar.PreClosePrice = ticks[0].PreClosePrice;

        bar.OpenInstruStatus = ticks[0].InstruStatus;
        bar.CloseInstruStatus = ticks[ticks.size() - 1].InstruStatus;

        if (ticks[0].Exchange == "SHSE") {
            bar.PreCloseIOPV = 0.0;
        } else {
            bar.PreCloseIOPV = ticks[0].PreCloseIOPV;
        }

        if (ticks[0].ts == DEFAULT_TIMEFRAME)
            cerr << "UNKNOWN ERROR IN BUILD BAR" << endl;

        return bar;
    }

    bondBar BuildBar(vector<bondTick> &ticks, const int timeframe, const bondTick &pretick, const bool isorder) { 
        if (ticks.empty()) return bondBar();

        if  (!isorder) {
            sort(ticks.begin(), ticks.end(),
                [](const bondTick& a, const bondTick& b) {
                    return a.ts < b.ts;  // 升序
                });
        }

        // 验证输入数据是否在一个 timeframe 内
        // ts: YYYYMMDDHHMMSSMMM
        if (!ticks.empty()) {
            if (ticks[ticks.size() - 1].ts - ticks[0].ts > timeframe * 100000) {
                cerr << "数据时间间隔超出 timeframe" << endl;   
                return bondBar();
            }
        }

        bondBar bar;

        bar.timeframe = timeframe;
        bar.StockID = ticks[0].StockID;
        bar.Exchange = ticks[0].Exchange;

        bar.ts = GetTickBarLabel(ticks[0].ts, timeframe);
        bar.Close = ticks[ticks.size() - 1].LastPrice;
        bar.Open = ticks[0].LastPrice;
        bar.High = ticks[0].LastPrice; // 后面会遍历更新
        bar.Low = ticks[0].LastPrice;

        bar.ULimitPrice = ticks[0].UpperLimitPrice;
        bar.LLimitPrice = ticks[0].LowerLimitPrice;
        bar.TradeDay = stoll(ticks[0].TradingDay);

        bar.TotalBidQty = ticks[0].TotalBidQty;
        bar.TotalOfferQty = ticks[0].TotalOfferQty;

        double VWap = 0;
        if (pretick.ts == DEFAULT_TIMEFRAME) {
            bar.Volume = ticks[ticks.size() - 1].Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum;
    
            VWap += ticks[0].Volume * ticks[0].LastPrice;
        } else {
            bar.Volume = ticks[ticks.size() - 1].Volume - pretick.Volume;
            bar.Turnover = ticks[ticks.size() - 1].Turnover - pretick.Turnover;
            bar.TurnNum = ticks[ticks.size() - 1].TurnNum - pretick.TurnNum;
            VWap += (ticks[0].Volume - pretick.Volume)*ticks[0].LastPrice;
        }

        double ticksize = getticksize(ticks[0]);

        for (int i = 1; i < ticks.size(); i++)
        {
            auto pretick = ticks.at(i - 1);
            auto tick = ticks.at(i);
            bar.TotalBidQty += tick.TotalBidQty;
            bar.TotalOfferQty += tick.TotalOfferQty;
            double p = tick.LastPrice;
            if (p > bar.High){
                bar.High = p;
            }
            if (p < bar.Low) {
                bar.Low = p;
            }
            
            VWap += (tick.Volume - pretick.Volume) * tick.LastPrice;
        }
        if (bar.Volume > 0)
        {
            bar.Vwap = NormalizePrice(VWap / bar.Volume, ticksize);
        }
        else
        {
            bar.Vwap = bar.Close;
        }

        bar.PreClosePrice = ticks[0].PreClosePrice;

        bar.OpenInstruStatus = ticks[0].InstruStatus;
        bar.CloseInstruStatus = ticks[ticks.size() - 1].InstruStatus;

        if (ticks[0].Exchange == "SHSE") {
            bar.YieldToMatu = ticks[0].YieldToMatu;
        } else {
            bar.YieldToMatu = 0.0;
        }

        if (ticks[0].ts == DEFAULT_TIMEFRAME)
            cerr << "UNKNOWN ERROR IN BUILD BAR" << endl;

        return bar;

    }

    unordered_map<string ,unordered_map<int,vector<etfBar>>> generateBarMap(
        unordered_map<string,vector<etfTick>>& maptick,
        const vector<int> &bar_timeframes) {

        unordered_map<string ,unordered_map<int,vector<etfBar>>> MapBar;
        if (maptick.empty()) return MapBar;

        for (auto& pair : maptick) {
            auto &ticks = pair.second;
            if (ticks.empty()) continue;
            string stockid = pair.first;

            vector<etfTick> valid_ticks;
            for (auto &tick : ticks) {
                if (tick.bar_flag && !isZero(tick.LastPrice)) {
                    valid_ticks.push_back(tick);
                }
            }
            if (valid_ticks.empty()) continue;


            bool having1440 = false;
            unordered_map<int, vector<etfTick>> barticksmap;
            etfTick emptyTick;
            emptyTick.ts = DEFAULT_TIMEFRAME;
            unordered_map<int, etfTick> preticks;
            unordered_map<int, uint64_t> pretickts;

            vector<int> non_daily_tfs;
            for (int tf : bar_timeframes) {
                if (tf == 1440) having1440 = true;
                else {
                    non_daily_tfs.push_back(tf);
                    preticks[tf] = emptyTick;
                    pretickts[tf] = valid_ticks.front().ts;
                }
            }

            for (auto &tick : valid_ticks){
                for (auto tf : non_daily_tfs){
                    if (TwoTickSameBar(tick.ts,pretickts[tf],tf)){
                        barticksmap[tf].push_back(tick);
                    }else{
                        auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                        MapBar[stockid][tf].push_back(bar);
                        barticksmap[tf].clear();
                        preticks[tf]=tick;
                        pretickts[tf]=tick.ts;
                    }
                }
            }
            for (auto &pair : barticksmap){
                if (!pair.second.empty()){
                    auto tf=pair.first;
                    auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                    MapBar[stockid][tf].push_back(bar);
                    barticksmap[tf].clear();
                }
            }

            // === 日线处理（1440）===
            if (having1440) {
                if (!valid_ticks.empty()) {
                    etfTick emptytick;
                    emptytick.ts = DEFAULT_TIMEFRAME; // 日线也使用 DEFAULT_TIMESTAMP 作为 pretick
                    etfBar daily_bar = BuildBar(valid_ticks, 1440, emptytick, true);
                    daily_bar.ts = stoull(valid_ticks.front().TradingDay + "160000000");
                    MapBar[stockid][1440].push_back(daily_bar);
                }
            }
        }

        return MapBar;
    }
    unordered_map<string ,unordered_map<int,vector<stockBar>>> generateBarMap(
        unordered_map<string,vector<stockTick>>& maptick,
        const vector<int> &bar_timeframes) {

        unordered_map<string ,unordered_map<int,vector<stockBar>>> MapBar;
        if (maptick.empty()) return MapBar;

        for (auto& pair : maptick) {
            auto &ticks = pair.second;
            if (ticks.empty()) continue;
            string stockid = pair.first;

            vector<stockTick> valid_ticks;
            for (auto &tick : ticks) {
                if (tick.bar_flag && !isZero(tick.LastPrice)) {
                    valid_ticks.push_back(tick);
                }
            }
            if (valid_ticks.empty()) continue;


            bool having1440 = false;
            unordered_map<int, vector<stockTick>> barticksmap;
            stockTick emptyTick;
            emptyTick.ts = DEFAULT_TIMEFRAME;
            unordered_map<int, stockTick> preticks;
            unordered_map<int, uint64_t> pretickts;

            vector<int> non_daily_tfs;
            for (int tf : bar_timeframes) {
                if (tf == 1440) having1440 = true;
                else {
                    non_daily_tfs.push_back(tf);
                    preticks[tf] = emptyTick;
                    pretickts[tf] = valid_ticks.front().ts;
                }
            }

            for (auto &tick : valid_ticks){
                for (auto tf : non_daily_tfs){
                    if (TwoTickSameBar(tick.ts,pretickts[tf],tf)){
                        barticksmap[tf].push_back(tick);
                    }else{
                        auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                        MapBar[stockid][tf].push_back(bar);
                        barticksmap[tf].clear();
                        preticks[tf]=tick;
                        pretickts[tf]=tick.ts;
                    }
                }
            }
            for (auto &pair : barticksmap){
                if (!pair.second.empty()){
                    auto tf=pair.first;
                    auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                    MapBar[stockid][tf].push_back(bar);
                    barticksmap[tf].clear();
                }
            }

            // === 日线处理（1440）===
            if (having1440) {
                if (!valid_ticks.empty()) {
                    stockTick emptytick;
                    emptytick.ts = DEFAULT_TIMEFRAME; // 日线也使用 DEFAULT_TIMESTAMP 作为 pretick
                    stockBar daily_bar = BuildBar(valid_ticks, 1440, emptytick, true);
                    daily_bar.ts = stoull(valid_ticks.front().TradingDay + "160000000");
                    MapBar[stockid][1440].push_back(daily_bar);
                }
            }
        }

        return MapBar;
    }
    unordered_map<string ,unordered_map<int,vector<indexBar>>> generateBarMap(
        unordered_map<string,vector<indexTick>>& maptick,
        const vector<int> &bar_timeframes) {

        unordered_map<string ,unordered_map<int,vector<indexBar>>> MapBar;
        if (maptick.empty()) return MapBar;

        for (auto& pair : maptick) {
            auto &ticks = pair.second;
            if (ticks.empty()) continue;
            string stockid = pair.first;

            vector<indexTick> valid_ticks;
            for (auto &tick : ticks) {
                if (tick.bar_flag && !isZero(tick.LastPrice)) {
                    valid_ticks.push_back(tick);
                }
            }
            if (valid_ticks.empty()) continue;


            bool having1440 = false;
            unordered_map<int, vector<indexTick>> barticksmap;
            indexTick emptyTick;
            emptyTick.ts = DEFAULT_TIMEFRAME;
            unordered_map<int, indexTick> preticks;
            unordered_map<int, uint64_t> pretickts;

            vector<int> non_daily_tfs;
            for (int tf : bar_timeframes) {
                if (tf == 1440) having1440 = true;
                else {
                    non_daily_tfs.push_back(tf);
                    preticks[tf] = emptyTick;
                    pretickts[tf] = valid_ticks.front().ts;
                }
            }

            for (auto &tick : valid_ticks){
                for (auto tf : non_daily_tfs){
                    if (TwoTickSameBar(tick.ts,pretickts[tf],tf)){
                        barticksmap[tf].push_back(tick);
                    }else{
                        auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                        MapBar[stockid][tf].push_back(bar);
                        barticksmap[tf].clear();
                        preticks[tf]=tick;
                        pretickts[tf]=tick.ts;
                    }
                }
            }
            for (auto &pair : barticksmap){
                if (!pair.second.empty()){
                    auto tf=pair.first;
                    auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                    MapBar[stockid][tf].push_back(bar);
                    barticksmap[tf].clear();
                }
            }

            // === 日线处理（1440）===
            if (having1440) {
                if (!valid_ticks.empty()) {
                    indexTick emptytick;
                    emptytick.ts = DEFAULT_TIMEFRAME; // 日线也使用 DEFAULT_TIMESTAMP 作为 pretick
                    indexBar daily_bar = BuildBar(valid_ticks, 1440, emptytick, true);
                    daily_bar.ts = stoull(valid_ticks.front().TradingDay + "160000000");
                    MapBar[stockid][1440].push_back(daily_bar);
                }
            }
        }

        return MapBar;
    }
    unordered_map<string ,unordered_map<int,vector<bondBar>>> generateBarMap(
        unordered_map<string,vector<bondTick>>& maptick,
        const vector<int> &bar_timeframes) {

        unordered_map<string ,unordered_map<int,vector<bondBar>>> MapBar;
        if (maptick.empty()) return MapBar;

        for (auto& pair : maptick) {
            auto &ticks = pair.second;
            if (ticks.empty()) continue;
            string stockid = pair.first;

            vector<bondTick> valid_ticks;
            for (auto &tick : ticks) {
                if (tick.bar_flag && !isZero(tick.LastPrice)) {
                    valid_ticks.push_back(tick);
                }
            }
            if (valid_ticks.empty()) continue;


            bool having1440 = false;
            unordered_map<int, vector<bondTick>> barticksmap;
            bondTick emptyTick;
            emptyTick.ts = DEFAULT_TIMEFRAME;
            unordered_map<int, bondTick> preticks;
            unordered_map<int, uint64_t> pretickts;

            vector<int> non_daily_tfs;
            for (int tf : bar_timeframes) {
                if (tf == 1440) having1440 = true;
                else {
                    non_daily_tfs.push_back(tf);
                    preticks[tf] = emptyTick;
                    pretickts[tf] = valid_ticks.front().ts;
                }
            }

            for (auto &tick : valid_ticks){
                for (auto tf : non_daily_tfs){
                    if (TwoTickSameBar(tick.ts,pretickts[tf],tf)){
                        barticksmap[tf].push_back(tick);
                    }else{
                        auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                        MapBar[stockid][tf].push_back(bar);
                        barticksmap[tf].clear();
                        preticks[tf]=tick;
                        pretickts[tf]=tick.ts;
                    }
                }
            }
            for (auto &pair : barticksmap){
                if (!pair.second.empty()){
                    auto tf=pair.first;
                    auto bar = BuildBar(barticksmap[tf],tf,preticks[tf],true);
                    MapBar[stockid][tf].push_back(bar);
                    barticksmap[tf].clear();
                }
            }

            // === 日线处理（1440）===
            if (having1440) {
                if (!valid_ticks.empty()) {
                    bondTick emptytick;
                    emptytick.ts = DEFAULT_TIMEFRAME; // 日线也使用 DEFAULT_TIMESTAMP 作为 pretick
                    bondBar daily_bar = BuildBar(valid_ticks, 1440, emptytick, true);
                    daily_bar.ts = stoull(valid_ticks.front().TradingDay + "160000000");
                    MapBar[stockid][1440].push_back(daily_bar);
                }
            }
        }

        return MapBar;
    }

};

