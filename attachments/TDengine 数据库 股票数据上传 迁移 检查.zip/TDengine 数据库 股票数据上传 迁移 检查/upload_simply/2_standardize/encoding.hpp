#include <unordered_map>
#include <string>
#include <vector>
using namespace std;

/*
    参考百度百科：https://baike.baidu.com/item/股票编码规则/6519583

    上交所统一使用 6 位编码
    深交所在2000年初由 4 位编码转换为 6 位
        由于所处理的股票均在 2000 年后，故不考虑深交所编码转换问题

*/

unordered_map<string,vector<string>> sh_encoding_map = {

    {
        // 股票
        "STOCK",
        {
            "60",   // 沪市主板股票
            "688",  // 科创板股票


            
        }
    },

    {
        // ETF
        "ETF",
        {
            "51",   // 沪市 ETF
            "588",  // 科创板 ETF
            "513",  // 跨境ETF（如纳指、港股） 



        }
    },

    {
        // 封闭式基金
        "FUND",
        {
            "500",  // 沪市基金
            

        }

    }, 

    {
        // LOF
        "LOF",
        {
            "5010", // 主流 LOF，多为主动管理型混合/股票型基金
            "5011", // 较少见，部分 QDII-LOF 或主题基金
            "5012", // 少量使用
            "5013", // 极少
            "5018", // 跨境/商品类 LOF（如黄金、原油）
            "5019", // 少量指数增强或策略 LOF
            "5020", // 主流指数型 LOF（最常见）
            "5021", // 指数 LOF 扩展 
            "5023", // 行业/主题指数 LOF
            "5024", "5025", "5026", "5027", "5028", "5029", // 零星使用，部分未启用或用于特殊品种
            "505",  // 多用于 跨境 QDII-LOF 或 商品基金
            "506",  // 主要用于 科创板、双创等主题 LOF
            "508",  // REITs（基础设施公募基金）


        }

    }, 

    {
        // 指数
        "INDEX",
        {
            "000", "950"  // 沪市指数

        }
    },

    {
        // 回购
        "BuyBack",
        {
            "204",  // 沪市回购


        }
    },

    {
        // 可转债
        "ConvertibleBond",
        {
            "11",   // 沪市可转债

        }

    },

    {
        // 新股申购
        "NewStockSubscription",
        {
            "73",   // 沪市新股申购

        }
    },

    {
        // 债券
        "BOND",
        {
            
            "12",   // 沪市企业债




        }
    },

    {
        // 国债
        "TB",
        {
            "019", "020",   // 沪市国债
        } 
    },  
    
    {
        // 期货
        "FUTURE",
        {
        }
    },

    {
        // 证券
        "SECURITY",
        {


        }

    },

    {
        // 权证
        "WARRANT",
        {




        }

    }

};

unordered_map<string,vector<string>> sz_encoding_map = {

    {
        // 股票
        "STOCK",
        {
            "00",   // 深市主板股票
            "30",   // 创业板股票

            
        }
    },

    {
        // 基金类
        "ETF",
        {
            "15",   // 深市ETF   
            

        }
    },

    {
        //  LOF
        "LOF",
        {
            "16",    // 深市LOF


        }

    },

    {
        "FOUND",
        {

        }
    },

    {
        // 指数
        "INDEX",
        {
           "399",   // 深市指数
        }
    },

    {
        // 回购
        "BuyBack",
        {
            "1318", // 深市回购
           

        }
    },

    {
        // 可转债
        "ConvertibleBond",
        {
           "12",    // 深市可转债

        }

    },

    {
        // 新股申购
        "NewStockSubscription",
        {

        }
    },

    {
        // 债券
        "BOND",
        {
            "11",   // 深市企业债
           
            



        }
    },

    {
        // 国债
        "TB",
        {
            "10",   // 深市国债
        } 
    },  
    
    {
        // 期货
        "FUTURE",
        {


        }
    },

    {
        // 证券
        "SECURITY",
        {


        }

    },

    {
        // 权证
        "WARRANT",
        {




        }

    }

};

unordered_map<string, string> make_enconding(const unordered_map<string, vector<string>> &encoding_map){
    unordered_map<string, string> rtn;
    for (auto & pair: encoding_map){
        auto & type = pair.first;
        for (auto & bgn: pair.second)
            rtn[bgn] = type;
    }
    return rtn;
}

// STOCKID 形如: 600100
string judge_type(const string &STOCKID, const unordered_map<string, string> &bgn_map){
    for (auto &pair: bgn_map){
        auto &bgn= pair.first;
        size_t bgn_size= bgn.size();
        if (STOCKID.substr(0,bgn_size)== bgn)
            return pair.second;
    }
    return "";
}
