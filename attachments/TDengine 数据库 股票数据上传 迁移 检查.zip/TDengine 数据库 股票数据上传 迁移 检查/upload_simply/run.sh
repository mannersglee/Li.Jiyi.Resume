# 0. 若C+程序被修改，请重新编译可以执行文件
/usr/bin/g++-9 -std=c++17 -O2 main.cpp -Iinclude -ltaos -pthread -o ./standardize_upload
chmod +x ./standardize_upload
# 1. 获取所有待上传文件
python3 get_all_file.py "${MARKET_DATA_ROOT:-/path/to/market-data}"
# 2. 标准化数据，上传taos数据库
python3 upload.py mission/SHSE.json -e SHSE
python3 upload.py mission/SZSE.json -e SZSE
# 3. 检查上传成功和失败的文件 ./mission/redo_* ./mission/undo_*

