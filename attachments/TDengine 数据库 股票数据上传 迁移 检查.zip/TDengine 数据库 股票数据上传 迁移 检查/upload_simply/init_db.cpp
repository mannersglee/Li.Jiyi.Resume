#include <iostream>
#include <filesystem>
#include <chrono>
#include <ctime>
#include <iomanip>

#include "2_standardize/loadJson.h"
#include "2_standardize/tick.hpp"
#include "2_standardize/bar.hpp"
#include "2_standardize/mapping.hpp"
#include "2_standardize/standardizeTick.hpp"
#include "2_standardize/toCsv.hpp"
#include "2_standardize/makeBar.hpp"

#include "3_upload/taosManager.hpp"

namespace fs = std::filesystem;
using namespace std;

void print_time(const string &info){
     auto now = std::chrono::system_clock::now();
    
    // 获取 time_t 部分 (秒)
    std::time_t now_time_t = std::chrono::system_clock::to_time_t(now);
    std::tm* local_tm = std::localtime(&now_time_t);

    // 获取毫秒部分
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()) % 1000;

    std::cout << std::put_time(local_tm, "%Y-%m-%d %H:%M:%S")
              << '.' << std::setfill('0') << std::setw(5) << ms.count()
              << ": "
              << info 
              << std::endl;
}

int main(int argc, char** argv) {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    string taos_config_path = "config/taos_config.json";
    if (argc != 2) {
        cout << "Usage: " << argv[0] << " <json_path>" << endl;
        // return 1;
    }else{
        taos_config_path = argv[1];
    }

    taos_config tc = taos_config::load_config(taos_config_path);
    TaosSQL taos(tc.host,tc.user,tc.password);

    // 建库和超级表
    taos.create_database("txy_stock");
    taos.create_tick_stable("txy_stock", "txy_tick", "STOCK");
    taos.create_bar_stable("txy_stock", "txy_bar", "STOCK");

    taos.create_database("txy_etf");
    taos.create_tick_stable("txy_etf", "txy_tick", "ETF");
    taos.create_bar_stable("txy_etf", "txy_bar", "ETF");

    // LOF haves the same struct as ETF's
    taos.create_database("txy_lof");
    taos.create_tick_stable("txy_lof", "txy_tick", "ETF");  
    taos.create_bar_stable("txy_lof", "txy_bar", "ETF");

    taos.create_database("txy_index");
    taos.create_tick_stable("txy_index", "txy_tick", "INDEX");
    taos.create_bar_stable("txy_index", "txy_bar", "INDEX");

    taos.create_database("txy_tb");
    taos.create_tick_stable("txy_tb", "txy_tick", "BOND");
    taos.create_bar_stable("txy_tb", "txy_bar", "BOND");

}
