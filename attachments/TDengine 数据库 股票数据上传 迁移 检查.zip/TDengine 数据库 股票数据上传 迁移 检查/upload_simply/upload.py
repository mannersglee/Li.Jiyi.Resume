import json
import subprocess
import argparse
import os
from get_all_file import get_all_file
from unzip import unzip_file
from datetime import datetime
from tools import *

DEFAULT_UNZIP_PASSWORD = os.getenv("MARKET_DATA_ZIP_PASSWORD")



def upload(mission_dict:dict, exchange:str):
    redo_list = {}
    undo_list = {}
    if exchange != 'SHSE' and exchange != 'SZSE':
        print('仅支持交易所SHSE,SZSE: ', exchange)
        return
    for date,file_path in mission_dict.items():
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        print_with_time(f'处理{date}_{exchange}')
        
        file_name = f'{date}_{exchange}.csv'
        tgt_file_path = f'./tmp/{date}_{exchange}.csv'
        if not os.path.exists(tgt_file_path):
            unzip_file(file_path, file_name, './tmp', DEFAULT_UNZIP_PASSWORD)
        if not os.path.exists(tgt_file_path):
            print_with_time(f'文件解压出现错误: {date}_{exchange}')
            update_json(f'./mission/redo_{exchange}.json',date,file_path)
            update_json(f'./error/error_info_{exchange}.json',date,"文件解压出现错误")

            continue
        print_with_time('开始标准化数据并上传')
        data_config = {
            "file_path": tgt_file_path,
            "date": date,
            "exchange": exchange,
            "chosen_stocks": [],
            "bar_timeframes": [5,15,30,1440],
            
            "loadstock": True,
            "loadetf": True,
            "loadindex": True,
            "loadbond": True,
            "loadbar": True,

            "debug": False
        }
        # 3. 将字典保存为 JSON 文件
        json_path = f'./tmp/{date}_{exchange}.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data_config, f, ensure_ascii=False, indent=4)
        log_file_path = f'./logs/{date}_{exchange}.log'
        with open(log_file_path, "w") as log_file:
            # 1. 使用 Popen 启动，它不会阻塞主进程
            proc = subprocess.Popen(
                ["./standardize_upload", json_path],
                stdout=log_file,
                stderr=subprocess.STDOUT
            )
            
            print_with_time(f"子进程已启动 (PID: {proc.pid})，开始实时监控...")

            # 2. 轮询检查子进程是否结束
            while proc.poll() is None:
                # 在这里调用你的 print_with_time，它会显示当前的实时总内存
                print_with_time(f"正在处理 {date}_{exchange}...")
                
                # 这里的 sleep 时间决定了你打印内存状态的频率
                time.sleep(60)

            # 3. 检查退出状态
            if proc.returncode != 0:
                print_with_time(f"子进程执行报错，退出码: {proc.returncode}")
            else:
                print_with_time("子进程执行完成")
        if date in os.listdir('./error'):
            print_with_time(f'文件上传出现错误{date}_{exchange}')
            os.remove(json_path)
            update_json(f'./mission/redo_{exchange}.json',date,file_path)
            update_json(f'./error/error_info_{exchange}.json',date,"数据库上传出现错误")
        else:
            print_with_time(f'处理完成{date}_{exchange}')
            os.remove(tgt_file_path)
            os.remove(json_path)
            os.remove(f'./logs/{date}_{exchange}.log')
            update_json(f'./mission/undo_{exchange}.json',date,file_path)
    return redo_list,undo_list

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('file_path', type=str, help='')
    parser.add_argument('-e', '--exchange', type=str, help='')
    args = parser.parse_args()
    memory_monitor_limit(40)
    with open(args.file_path, 'r', encoding='utf-8') as f:
        mission_dict = json.load(f)
        os.makedirs('./error',exist_ok=True)
        os.makedirs('./tmp',exist_ok=True)
        os.makedirs('./logs',exist_ok=True)
        redo_list,undo_list = upload(mission_dict,args.exchange)
        
    # with open('mission/SZSE.json', 'r', encoding='utf-8') as f:
    #     mission_dict = json.load(f)
    #     upload(mission_dict,'SZSE')
        
        
    
