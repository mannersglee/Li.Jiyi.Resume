import os
import json
import argparse

def get_all_file_after20160506(file_path:str, start:int = 19000101, end:int = 23000101):

    date_dir_list = os.listdir(file_path)

    sub_dir_list = os.listdir(file_path)

    miss_sz_list = []
    miss_sh_list = []

    sz_keyword_list = ['6_28_0']
    sh_keyword_list = ['marketdata','4_4_0']

    sz_mission_dict = {}
    sh_mission_dict = {}


    for sub_dir in sub_dir_list:
        current_path = os.path.join(file_path, sub_dir)
        
        # 确保当前路径是目录，防止处理到意外出现的文件
        if not os.path.isdir(current_path):
            continue

        having_sz = False
        having_sh = False

        # 遍历子目录下的所有文件
        for root, dirs, files in os.walk(current_path):
            if int(sub_dir) < start or int(sub_dir) < end:
                continue
            for file_name in files:
                
                file_name_lower = file_name.lower()
                
                for sz_keyword in sz_keyword_list:
                    if sz_keyword in file_name_lower:
                        having_sz = True
                        sz_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
                        
                for sh_keyword in sh_keyword_list:
                    if sh_keyword in file_name_lower:
                        having_sh = True
                        sh_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
                
                # 如果两个都找到了，提前跳出当前文件夹的循环，节省时间
                if having_sz and having_sh:
                    break
            
            if having_sz and having_sh:
                break

        try:
            dir_code = int(sub_dir)
            if not having_sh:
                miss_sh_list.append(dir_code)
            if not having_sz:
                miss_sz_list.append(dir_code)
        except ValueError:
            print(f"警告: 跳过非数字命名的文件夹 '{sub_dir}'")

    print('Missing SZ:')
    print(sorted(miss_sz_list))

    print('Missing SH:')
    print(sorted(miss_sh_list))


    sh_mission_dict = {k: sh_mission_dict[k] for k in sorted(sh_mission_dict.keys(), reverse=True)}
    sz_mission_dict = {k: sz_mission_dict[k] for k in sorted(sz_mission_dict.keys(), reverse=True)}

    os.makedirs('./mission', exist_ok=True)
    with open(f'./mission/SHSE.json', 'w', encoding='utf-8') as f:
        json.dump(sh_mission_dict, f, ensure_ascii=False, indent=4)
    with open(f'./mission/SZSE.json', 'w', encoding='utf-8') as f:
        json.dump(sz_mission_dict, f, ensure_ascii=False, indent=4)
    return sh_mission_dict,sz_mission_dict

def get_all_file(file_path:str, start:int = 19000101, end:int = 23000101):

    date_dir_list = os.listdir(file_path)
    sub_dir_list = os.listdir(file_path)

    miss_sz_list = []
    miss_sh_list = []

    sz_keyword_list = ['6_28_0']
    sh_keyword_list = ['marketdata','4_4_0']

    sz_mission_dict = {}
    sh_mission_dict = {}


    for sub_dir in sub_dir_list:
        if int(sub_dir) < start or int(sub_dir) > end:
            continue
        
        current_path = os.path.join(file_path, sub_dir)
        
        # 确保当前路径是目录，防止处理到意外出现的文件
        if not os.path.isdir(current_path):
            continue
        
        organize_type = 1
        having_sz = False
        having_sh = False
        
        for i in os.listdir(current_path):
            if 'sh' in i.lower() or 'sz' in i.lower():
                organize_type = 2
            
            if 'sh' in i.lower() and not having_sh:
                for root, dirs, files in os.walk(os.path.join(current_path,i)):
                    for file_name in files:
                        file_name_lower = file_name.lower()
                        if 'marketdata' in file_name_lower and 'csv' in file_name_lower:
                            having_sh = True
                            sh_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
            if 'sz' in i.lower() and not having_sz:
                for root, dirs, files in os.walk(os.path.join(current_path,i)):
                    for file_name in files:
                        file_name_lower = file_name.lower()
                        if 'marketdata' in file_name_lower and 'csv' in file_name_lower:
                            having_sz = True
                            sz_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
        if (organize_type == 2):
            dir_code = int(sub_dir)
            if not having_sh:
                miss_sh_list.append(dir_code)
            if not having_sz:
                miss_sz_list.append(dir_code)
        else:
            # 遍历子目录下的所有文件
            for root, dirs, files in os.walk(current_path):
                for file_name in files:
                    
                    file_name_lower = file_name.lower()
                    
                    for sz_keyword in sz_keyword_list:
                        if sz_keyword in file_name_lower and 'csv' in file_name_lower:
                            having_sz = True
                            sz_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
                            
                    for sh_keyword in sh_keyword_list:
                        if sh_keyword in file_name_lower and 'csv' in file_name_lower:
                            having_sh = True
                            sh_mission_dict[int(sub_dir)] = os.path.join(root, file_name)
                    
                    # 如果两个都找到了，提前跳出当前文件夹的循环，节省时间
                    if having_sz and having_sh:
                        break
                
                if having_sz and having_sh:
                    break

            try:
                dir_code = int(sub_dir)
                if not having_sh:
                    miss_sh_list.append(dir_code)
                if not having_sz:
                    miss_sz_list.append(dir_code)
            except ValueError:
                print(f"警告: 跳过非数字命名的文件夹 '{sub_dir}'")

    print('Missing SZ:')
    print(sorted(miss_sz_list))

    print('Missing SH:')
    print(sorted(miss_sh_list))


    sh_mission_dict = {k: sh_mission_dict[k] for k in sorted(sh_mission_dict.keys(), reverse=True)}
    sz_mission_dict = {k: sz_mission_dict[k] for k in sorted(sz_mission_dict.keys(), reverse=True)}

    os.makedirs('./mission', exist_ok=True)
    with open(f'./mission/SHSE.json', 'w', encoding='utf-8') as f:
        json.dump(sh_mission_dict, f, ensure_ascii=False, indent=4)
    with open(f'./mission/SZSE.json', 'w', encoding='utf-8') as f:
        json.dump(sz_mission_dict, f, ensure_ascii=False, indent=4)
    return sh_mission_dict,sz_mission_dict

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='扫描股票数据根目录，得到所有待上传数据压缩包路径')

    parser.add_argument('file_path', type=str, help='输入压缩文件的绝对或相对路径')
    parser.add_argument('-s', '--start', type=int, default='19000101', help='待处理数据开始日期')
    parser.add_argument('-e', '--end', type=int, default='23000101', help='待处理数据结束日期')

    args = parser.parse_args()
    get_all_file(args.file_path,args.start,args.end)
    
    
    
    
    
    