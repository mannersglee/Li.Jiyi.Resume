## 如何开启 TAOS 数据库监控：

 编辑 TDengine 的主配置文件：`/etc/taos/taos.cfg`

```
# 启用监控功能（默认为 1，即开启）
monitor 1

# 指定监控数据库名称（默认为 log）
monitorDatabase log

# 可选：设置监控数据保留天数（默认为 15 天）
monitorKeep 15
```

重启 taosd 服务使配置生效：

```bash
sudo systemctl restart taosd
# 或使用 service
sudo service taosd restart
```

## 查询CPU, Memory, Disk, I/O：

```sql
USE log;
SELECT dnode_id, dnode_ep, cpu_engine, mem_engine, disk_used, io_read, io_write, _ts
            FROM taosd_dnodes_info
            WHERE _ts >= now()-5m;
```

> dnode_ep 会用于下一步查询

## 查询内存使用情况：

```sql
USE log;
SELECT _ts, mem_total, mem_free, mem_engine 
FROM taosd_dnodes_info 
WHERE dnode_ep = 'txytrain105:6030' 
ORDER BY _ts DESC 
LIMIT 1;
```

> txytraining:6030 是上一步的 dnode_ep 
>
> 所有内存单位均为字节（bytes）

## 增加 TDengine 内存

#### 编辑配置文件

```sql
sudo vim /etc/taos/taos.cfg
```

#### 修改或添加以下行（示例：分配 4GB 内存）

```
# 增加 buffer 到 4096 MB（即 4GB）
buffer 4096

# 可选：限制 vnode 数量（避免元数据占用过多内存）
maxVnodePerDb 200

# 可选：适当增加线程数（根据 CPU 核数）
numOfRpcThreads 4
numOfCommitThreads 4
```

#### 保存并重启 TDengine

```bash
sudo systemctl restart taosd
# 或
sudo service taosd restart
```

#### 查看日志确认验证配置是否生效：

```bash
sudo tail -f /var/log/taos/taosdlog.0
```

