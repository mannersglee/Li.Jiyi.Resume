## 数据库优化

问题：TAOS `3.3.6.0` 修改 `taos.cfg` 的 `monitor=1`，`taos> show variables` 中也显示 `monitor=1`，但是没有 `log`  库

![屏幕截图 2025-12-31 150807](/assets/屏幕截图 2025-12-31 150807-1767172432907-3.png)

解决：启动这两个服务

```bash
systemctl start taosadapter
systemctl start taoskeeper
```



查看当前服务器配置参数：

```bash
taosd -C
```

![image-20260105092217018](C:\Users\Administrator\Desktop\assets\image-20260105092217018.png)

配置文件多打了一个：`/`

指定配置文件位置：

```bash
taosd -c /etc/taos/taos.cfg
taos -c /etc/taos/taos.cfg
```



![image-20260105093658161](C:\Users\Administrator\Desktop\assets\image-20260105093658161.png)



问题：TAOS `3.3.6.0` 创建数据库指定优化参数，

https://docs.taosdata.com/3.3.0/taos-sql/database/

```sql
CREATE DATABASE [IF NOT EXISTS] db_name [database_options]
 
database_options:
    database_option ...
 
database_option: {
    BUFFER value
  | CACHEMODEL {'none' | 'last_row' | 'last_value' | 'both'}
  | CACHESIZE value
  | COMP {0 | 1 | 2}
  | DURATION value
  | WAL_FSYNC_PERIOD value
  | MAXROWS value
  | MINROWS value
  | KEEP value
  | PAGES value
  | PAGESIZE  value
  | PRECISION {'ms' | 'us' | 'ns'}
  | REPLICA value
  | WAL_LEVEL {1 | 2}
  | VGROUPS value
  | SINGLE_STABLE {0 | 1}
  | STT_TRIGGER value
  | TABLE_PREFIX value
  | TABLE_SUFFIX value
  | TSDB_PAGESIZE value
  | WAL_RETENTION_PERIOD value
  | WAL_RETENTION_SIZE value
}
```

- BUFFER: 一个 VNODE 写入内存池大小，单位为 MB，默认为 256，最小为 3，最大为 16384。
- CACHEMODEL：表示是否在内存中缓存子表的最近数据。默认为 none。
  - none：表示不缓存。
  - last_row：表示缓存子表最近一行数据。这将显著改善 LAST_ROW 函数的性能表现。
  - last_value：表示缓存子表每一列的最近的非 NULL 值。这将显著改善无特殊影响（WHERE、ORDER BY、GROUP BY、INTERVAL）下的 LAST 函数的性能表现。
  - both：表示同时打开缓存最近行和列功能。 Note：CacheModel 值来回切换有可能导致 last/last_row 的查询结果不准确，请谨慎操作。推荐保持打开。
- CACHESIZE：表示每个 vnode 中用于缓存子表最近数据的内存大小。默认为 1 ，范围是[1, 65536]，单位是 MB。
- COMP：表示数据库文件压缩标志位，缺省值为 2，取值范围为 [0, 2]。
  - 0：表示不压缩。
  - 1：表示一阶段压缩。
  - 2：表示两阶段压缩。
- DURATION：数据文件存储数据的时间跨度。可以使用加单位的表示形式，如 DURATION 100h、DURATION 10d 等，支持 m（分钟）、h（小时）和 d（天）三个单位。不加时间单位时默认单位为天，如 DURATION 50 表示 50 天。
- WAL_FSYNC_PERIOD：当 WAL_LEVEL 参数设置为 2 时，用于设置落盘的周期。默认为 3000，单位毫秒。最小为 0，表示每次写入立即落盘；最大为 180000，即三分钟。
- MAXROWS：文件块中记录的最大条数，默认为 4096 条。
- MINROWS：文件块中记录的最小条数，默认为 100 条。
- KEEP：表示数据文件保存的天数，缺省值为 3650，取值范围 [1, 365000]，且必须大于或等于3倍的 DURATION 参数值。数据库会自动删除保存时间超过 KEEP 值的数据。KEEP 可以使用加单位的表示形式，如 KEEP 100h、KEEP 10d 等，支持 m（分钟）、h（小时）和 d（天）三个单位。也可以不写单位，如 KEEP 50，此时默认单位为天。企业版支持[多级存储](https://docs.taosdata.com/tdinternal/arch/#多级存储)功能, 因此, 可以设置多个保存时间（多个以英文逗号分隔，最多 3 个，满足 keep 0 <= keep 1 <= keep 2，如 KEEP 100h,100d,3650d）; 社区版不支持多级存储功能（即使配置了多个保存时间, 也不会生效, KEEP 会取最大的保存时间）。
- PAGES：一个 VNODE 中元数据存储引擎的缓存页个数，默认为 256，最小 64。一个 VNODE 元数据存储占用 PAGESIZE * PAGES，默认情况下为 1MB 内存。
- PAGESIZE：一个 VNODE 中元数据存储引擎的页大小，单位为 KB，默认为 4 KB。范围为 1 到 16384，即 1 KB 到 16 MB。
- PRECISION：数据库的时间戳精度。ms 表示毫秒，us 表示微秒，ns 表示纳秒，默认 ms 毫秒。
- REPLICA：表示数据库副本数，取值为 1、2 或 3，默认为 1; 2 仅在企业版 3.3.0.0 及以后版本中可用。在集群中使用，副本数必须小于或等于 DNODE 的数目。
- WAL_LEVEL：WAL 级别，默认为 1。
  - 1：写 WAL，但不执行 fsync。
  - 2：写 WAL，而且执行 fsync。
- VGROUPS：数据库中初始 vgroup 的数目。
- SINGLE_STABLE：表示此数据库中是否只可以创建一个超级表，用于超级表列非常多的情况。
  - 0：表示可以创建多张超级表。
  - 1：表示只可以创建一张超级表。
- STT_TRIGGER：表示落盘文件触发文件合并的个数。默认为 1，范围 1 到 16。对于少表高频场景，此参数建议使用默认配置，或较小的值；而对于多表低频场景，此参数建议配置较大的值。
- TABLE_PREFIX：当其为正值时，在决定把一个表分配到哪个 vgroup 时要忽略表名中指定长度的前缀；当其为负值时，在决定把一个表分配到哪个 vgroup 时只使用表名中指定长度的前缀；例如，假定表名为 "v30001"，当 TSDB_PREFIX = 2 时 使用 "0001" 来决定分配到哪个 vgroup ，当 TSDB_PREFIX = -2 时使用 "v3" 来决定分配到哪个 vgroup
- TABLE_SUFFIX：当其为正值时，在决定把一个表分配到哪个 vgroup 时要忽略表名中指定长度的后缀；当其为负值时，在决定把一个表分配到哪个 vgroup 时只使用表名中指定长度的后缀；例如，假定表名为 "v30001"，当 TSDB_SUFFIX = 2 时 使用 "v300" 来决定分配到哪个 vgroup ，当 TSDB_SUFFIX = -2 时使用 "01" 来决定分配到哪个 vgroup。
- TSDB_PAGESIZE：一个 VNODE 中时序数据存储引擎的页大小，单位为 KB，默认为 4 KB。范围为 1 到 16384，即 1 KB到 16 MB。
- WAL_RETENTION_PERIOD: 为了数据订阅消费，需要WAL日志文件额外保留的最大时长策略。WAL日志清理，不受订阅客户端消费状态影响。单位为 s。默认为 3600，表示在 WAL 保留最近 3600 秒的数据，请根据数据订阅的需要修改这个参数为适当值。
- WAL_RETENTION_SIZE：为了数据订阅消费，需要WAL日志文件额外保留的最大累计大小策略。单位为 KB。默认为 0，表示累计大小无上限。



```sql
CREATE DATABASE IF NOT EXISTS test_db
  BUFFER 1024                -- 提高内存池，适应高频写入（默认256太小）
  CACHEMODEL 'both'          -- 同时缓存 last_row 和 last_value，极大加速 LAST/LAST_ROW 查询
  CACHESIZE 64               -- 每 vnode 缓存 64MB 最近数据（默认1太小）
  COMP 2                     -- 两阶段压缩，节省磁盘（tick数据重复率高，压缩效果好）
  KEEP 3650d                 -- 保留10年（按需调整）
  MAXROWS 8192               -- 增大块容量，减少元数据开销（默认4096偏小）
  MINROWS 1000               -- 避免过小块（默认100太碎）
  PAGES 512                  -- 元数据缓存页数翻倍（默认256）
  PAGESIZE 8                 -- 元数据页大小8KB（默认4KB）
  TSDB_PAGESIZE 16           -- 时序数据页增大到16KB，提升I/O效率
  PRECISION 'ms'             -- 你的时间戳是毫秒级（如 09:17:18.000）
  WAL_LEVEL 2                -- 强一致性，防止宕机丢数据（金融场景必须）
  WAL_FSYNC_PERIOD 3000       -- 每100ms强制刷盘（平衡性能与安全，默认3000太慢）
  STT_TRIGGER 4              -- 触发合并的文件数设为4（避免too many files）
  VGROUPS 4                  -- 初始4个vgroup，便于水平扩展（根据节点数调整）
--  SINGLE_STABLE 1            -- 若只用一个超级表（如 S601800 所有tick共用结构），开启可提升性能
--  DURATION 1d                -- 每个数据文件覆盖1天（适合按日分析）
;
```

```sql

CREATE DATABASE IF NOT EXISTS test_db BUFFER 1024 CACHEMODEL 'both' CACHESIZE 64 COMP 2 KEEP 3650d MAXROWS 8192 MINROWS 1000 PAGES 512 PAGESIZE 8 TSDB_PAGESIZE 16 PRECISION 'ms' WAL_LEVEL 2 WAL_FSYNC_PERIOD 3000 STT_TRIGGER 4 VGROUPS 4;
```

