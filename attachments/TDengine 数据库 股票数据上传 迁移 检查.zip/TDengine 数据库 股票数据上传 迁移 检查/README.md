# TDengine 股票行情数据工具集

面向 TDengine 的股票行情数据处理项目，覆盖三条核心链路：

- `upload_simply/`: 通联行情压缩包解压、标准化、批量写入 TDengine。
- `data_migration/`: 按时间窗口从源 TDengine 集群下载数据，并迁移到目标集群。
- `data_check/`: 多节点数据自检、一致性校验、缺失表补齐与异常行修复。

## 重构亮点

- 抽取 `common/` 共享模块，统一配置加载、运行时日志/内存监控、CSV 分片、TDengine 访问和一致性校验逻辑。
- 移除硬编码内网 IP、账号、密码；真实配置改由本地 JSON 或环境变量提供。
- 删除临时行情 CSV、运行日志、`pycache`、编译产物等不适合进入作品集的文件。
- 保留原脚本入口的兼容层，降低迁移成本，同时让核心能力集中复用。

## 目录结构

```text
common/                 Python 共享基础模块
data_check/             TDengine 多节点数据校验与修复
data_migration/         TDengine 数据迁移脚本
upload_simply/          行情文件标准化与上传工具，含 C++ 高性能处理逻辑
TAOS/                   TDengine 运维记录
通联沪深数据说明/        数据源协议与字段说明文档
```

## 配置

复制示例配置后填写本地连接信息：

```bash
cp data_check/config/settings.example.json data_check/config/settings.json
cp data_migration/config/migration_info.example.json data_migration/config/migration_info.json
```

也可以通过环境变量运行迁移脚本：

```bash
export SRC_TAOS_HOST=127.0.0.1
export SRC_TAOS_USER=root
export SRC_TAOS_PASSWORD=your-password
export DST_TAOS_HOST=127.0.0.2
export DST_TAOS_USER=root
export DST_TAOS_PASSWORD=your-password
```

## 运行

```bash
cd data_check
python main.py

cd ../data_migration
python download.py
python upload.py
```

`upload_simply/` 中的 C++ 程序依赖 TDengine C 客户端和 `g++`，运行前需要按本机环境重新编译。

## 安全说明

仓库中不应包含真实数据库地址、账号、密码、生产行情数据、运行日志或编译产物。`.gitignore` 已覆盖这些文件类型，提交前仍建议执行一次敏感信息扫描。

