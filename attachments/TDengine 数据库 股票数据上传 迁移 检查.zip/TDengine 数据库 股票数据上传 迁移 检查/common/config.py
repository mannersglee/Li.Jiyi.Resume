import datetime as dt
import os
from dataclasses import dataclass
from pathlib import Path

from common.runtime import load_json


DEFAULT_DATABASES = ["txy_etf", "txy_stock", "txy_lof", "txy_index", "txy_tb"]
DEFAULT_TRADING_TIME = [
    dt.time(9, 30),
    dt.time(11, 30),
    dt.time(13, 0),
    dt.time(15, 0),
]


@dataclass(frozen=True)
class TaosConfig:
    host: str
    port: int = 6030
    user: str = "root"
    password: str = ""

    @classmethod
    def from_env(cls, prefix: str) -> "TaosConfig":
        return cls(
            host=os.environ[f"{prefix}_HOST"],
            port=int(os.getenv(f"{prefix}_PORT", "6030")),
            user=os.getenv(f"{prefix}_USER", "root"),
            password=os.getenv(f"{prefix}_PASSWORD", ""),
        )


def load_check_settings(path: str | Path = "data_check/config/settings.json") -> dict:
    config = load_json(path, {})
    taos_config = config.get("taos_config", {})
    if not taos_config and os.getenv("TAOS_HOST"):
        taos_config = {
            os.getenv("TAOS_ALIAS", os.environ["TAOS_HOST"]): TaosConfig.from_env("TAOS").__dict__
        }

    return {
        "taos_config_dict": taos_config,
        "original_host": config.get("original_host") or next(iter(taos_config), ""),
        "database_list": config.get("database_list", DEFAULT_DATABASES),
        "trading_time": DEFAULT_TRADING_TIME,
    }


def load_migration_settings(path: str | Path = "data_migration/config/migration_info.json") -> dict:
    config = load_json(path, {})
    if config:
        return config
    if os.getenv("SRC_TAOS_HOST") and os.getenv("DST_TAOS_HOST"):
        src = TaosConfig.from_env("SRC_TAOS")
        dst = TaosConfig.from_env("DST_TAOS")
        return {
            "database": os.getenv("MIGRATION_DATABASE", "txy_stock"),
            "start": int(os.getenv("MIGRATION_START", "20230101")),
            "end": int(os.getenv("MIGRATION_END", "20230102")),
            "batch": int(os.getenv("MIGRATION_BATCH_HOURS", "24")),
            "migratetick": os.getenv("MIGRATE_TICK", "true").lower() == "true",
            "migratebar": os.getenv("MIGRATE_BAR", "true").lower() == "true",
            "src_host": src.host,
            "src_port": src.port,
            "src_user": src.user,
            "src_password": src.password,
            "dst_host": dst.host,
            "dst_port": dst.port,
            "dst_user": dst.user,
            "dst_password": dst.password,
        }
    return config

