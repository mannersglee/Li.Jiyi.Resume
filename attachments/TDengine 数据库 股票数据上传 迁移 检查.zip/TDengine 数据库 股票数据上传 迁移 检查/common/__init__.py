"""Shared helpers for the TDengine market data toolkit."""

