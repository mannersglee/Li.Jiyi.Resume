import json
import os
import signal
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import psutil


def load_json(path: str | Path, default: Any = None) -> Any:
    file_path = Path(path)
    if not file_path.exists():
        return {} if default is None else default
    with file_path.open("r", encoding="utf-8") as file:
        content = file.read().strip()
    if not content:
        return {} if default is None else default
    return json.loads(content)


def update_json(path: str | Path, key: str, value: Any) -> dict[str, Any]:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    data = load_json(file_path, {})
    data[key] = value
    tmp_path = file_path.with_suffix(file_path.suffix + ".tmp")
    with tmp_path.open("w", encoding="utf-8") as file:
        json.dump(data, file, ensure_ascii=False, indent=4)
    tmp_path.replace(file_path)
    return data


def get_total_memory_usage_mb() -> float:
    try:
        process = psutil.Process(os.getpid())
        total = process.memory_info().rss
        for child in process.children(recursive=True):
            try:
                total += child.memory_info().rss
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return total / 1024 / 1024
    except Exception:
        return 0.0


def print_with_time(message: str) -> None:
    now = datetime.now()
    time_str = now.strftime("%H:%M:%S.") + f"{now.microsecond:06d}"[:3]
    print(f"{time_str} [{get_total_memory_usage_mb():.2f} MB]: {message}")


def start_memory_guard(limit_gb: float, check_interval: int = 5) -> None:
    limit_mb = limit_gb * 1024

    def monitor() -> None:
        while True:
            current = get_total_memory_usage_mb()
            if current > limit_mb:
                print_with_time(f"内存占用 {current:.2f} MB 超过上限 {limit_mb:.2f} MB，终止进程。")
                parent = psutil.Process(os.getpid())
                for child in parent.children(recursive=True):
                    try:
                        child.kill()
                    except psutil.NoSuchProcess:
                        pass
                os.kill(os.getpid(), signal.SIGKILL)
            time.sleep(check_interval)

    threading.Thread(target=monitor, daemon=True).start()
    print_with_time(f"内存守护进程已启动，上限: {limit_gb} GB")


memory_monitor_limit = start_memory_guard
get_total_memory_usage = get_total_memory_usage_mb

