import json
import logging
import os
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Iterator

import pandas as pd
import taos

from common.csv_utils import prepare_csv


class TaosManager:
    def __init__(self, host: str, port: int, user: str, password: str):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.conn = taos.connect(host=host, port=port, user=user, password=password)

    def __enter__(self) -> "TaosManager":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    @contextmanager
    def cursor(self) -> Iterator:
        cursor = self.conn.cursor()
        try:
            yield cursor
        finally:
            cursor.close()

    def close(self) -> None:
        try:
            self.conn.close()
        except Exception as exc:
            logging.warning("Close connection failed for %s: %s", self.host, exc)

    def save_conn_config(self, save_path: str | Path) -> str:
        Path(save_path).mkdir(parents=True, exist_ok=True)
        config = {"host": self.host, "port": self.port, "user": self.user, "password": self.password}
        json_path = Path(save_path) / f"{self.host}_connection.json"
        with json_path.open("w", encoding="utf-8") as file:
            json.dump(config, file, ensure_ascii=False, indent=4)
        return str(json_path)

    def execute_sql(self, sql: str) -> None:
        with self.cursor() as cursor:
            cursor.execute(sql)

    def get_database_list(self) -> list[str]:
        with self.cursor() as cursor:
            cursor.execute("SHOW DATABASES")
            return [row[0] for row in cursor.fetchall()]

    def get_table_list(self, database: str) -> list[str]:
        with self.cursor() as cursor:
            cursor.execute(f"SHOW {database}.TABLES")
            return [row[0] for row in cursor.fetchall()]

    get_all_table_name = get_table_list

    def get_table(self, database: str, table: str, start: str = "19000101", end: str = "23000101", batch: int = 120) -> pd.DataFrame:
        return self.get_table_data_ts_batch(
            database,
            table,
            datetime.strptime(str(start), "%Y%m%d"),
            datetime.strptime(str(end), "%Y%m%d"),
            batch,
        )

    def get_table_data_ts_batch(
        self,
        database: str,
        table: str,
        start_ts: datetime,
        end_ts: datetime,
        batch: int,
    ) -> pd.DataFrame:
        frames: list[pd.DataFrame] = []
        current_start = start_ts
        step = timedelta(hours=batch)
        with self.cursor() as cursor:
            while current_start < end_ts:
                current_end = min(current_start + step, end_ts)
                sql = (
                    f"SELECT * FROM {database}.{table} "
                    f"WHERE ts >= '{current_start:%Y-%m-%d %H:%M:%S}' "
                    f"AND ts < '{current_end:%Y-%m-%d %H:%M:%S}'"
                )
                cursor.execute(sql)
                rows = cursor.fetchall()
                if rows:
                    frames.append(pd.DataFrame(rows, columns=[desc[0] for desc in cursor.description]))
                current_start = current_end
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()

    def create_table(self, database: str, table: str, table_type: str) -> None:
        if "tick" in table_type.lower():
            stock_id = table.split("_")[0]
            sql = f"CREATE TABLE IF NOT EXISTS {database}.{table} USING {database}.txy_tick TAGS ('{stock_id}')"
        else:
            stock_id, timeframe = table.split("_")
            sql = (
                f"CREATE TABLE IF NOT EXISTS {database}.{table} USING {database}.txy_bar "
                f"TAGS ('{stock_id}', {timeframe.replace('m', '')})"
            )
        self.execute_sql(sql)

    def delete_row(self, database: str, table: str, ts: str) -> None:
        self.execute_sql(f"DELETE FROM {database}.{table} WHERE ts = '{ts}'")

    def insert_dataframe(self, database: str, table: str, df: pd.DataFrame, table_type: str) -> None:
        col_str, csv_paths = prepare_csv(df)
        if not csv_paths:
            return
        self.create_table(database, table, table_type)
        try:
            for csv_path in csv_paths:
                self.execute_sql(f"INSERT INTO {database}.{table} ({col_str}) FILE '{csv_path}'")
        finally:
            for csv_path in csv_paths:
                if os.path.exists(csv_path):
                    os.remove(csv_path)

    def insert_csv(self, database: str, table: str, csv_file: str, table_type: str) -> None:
        if os.path.exists(csv_file):
            self.insert_dataframe(database, table, pd.read_csv(csv_file, index_col=False), table_type)

    def insert_tick_csv_title(self, database: str, table: str, csv_file: str) -> None:
        self.insert_csv(database, table, csv_file, "tick")

    def insert_bar_csv_title(self, database: str, table: str, csv_file: str) -> None:
        self.insert_csv(database, table, csv_file, "bar")

    def insert_tick_dataframe_title(self, database: str, table: str, df: pd.DataFrame) -> None:
        self.insert_dataframe(database, table, df, "tick")

    def insert_bar_dataframe_title(self, database: str, table: str, df: pd.DataFrame) -> None:
        self.insert_dataframe(database, table, df, "bar")


taos_manager = TaosManager
