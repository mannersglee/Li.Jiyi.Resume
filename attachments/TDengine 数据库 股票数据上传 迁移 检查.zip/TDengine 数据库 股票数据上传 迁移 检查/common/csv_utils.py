import os
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd


def split_dataframe_to_csv(
    df: pd.DataFrame,
    max_size_mb: int = 50,
    output_dir: str | Path = "./tmp",
) -> list[str]:
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    if df.empty:
        return []

    sample_size = min(1000, len(df))
    sample_bytes = len(df.iloc[:sample_size].to_csv(index=False, header=False).encode("utf-8"))
    avg_bytes_per_row = max(1, sample_bytes / sample_size)
    max_bytes = max_size_mb * 1024 * 1024 * 0.8
    rows_per_file = max(1, int(max_bytes // avg_bytes_per_row))

    paths: list[str] = []
    for start in range(0, len(df), rows_per_file):
        chunk = df.iloc[start : start + rows_per_file]
        fd, path = tempfile.mkstemp(prefix="taos_", suffix=".csv", dir=output_dir)
        os.close(fd)
        chunk.to_csv(path, index=False, header=False)
        paths.append(path)
    return paths


def prepare_csv(
    df: pd.DataFrame,
    max_size_mb: int = 50,
    output_dir: str | Path = "./tmp",
) -> tuple[str, list[str]]:
    if df.empty:
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        return "", []

    result = df.dropna(axis=1, how="all").copy()
    if "ts" in result.columns:
        result["ts"] = result["ts"].astype("object")

    object_columns = result.select_dtypes(include=["object"]).columns
    if len(object_columns) > 0:
        result.loc[:, object_columns] = result[object_columns].where(
            result[object_columns].isna(),
            "'" + result[object_columns].astype(str) + "'",
        )

    object_mask = result.dtypes == "object"
    if object_mask.any():
        result.loc[:, object_mask] = result.loc[:, object_mask].fillna("NULL")

    number_mask = result.dtypes.apply(lambda dtype: np.issubdtype(dtype, np.number))
    if number_mask.any():
        result.loc[:, number_mask] = result.loc[:, number_mask].fillna(0)

    return ",".join(result.columns), split_dataframe_to_csv(result, max_size_mb, output_dir)

