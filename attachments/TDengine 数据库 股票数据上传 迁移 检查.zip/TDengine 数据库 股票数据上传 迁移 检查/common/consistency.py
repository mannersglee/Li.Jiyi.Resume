import numpy as np
import pandas as pd


def check_dataframe_consistency(
    dataframe_dict: dict[str, pd.DataFrame],
    original_host: str,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    all_indices = pd.Index([])
    all_columns = pd.Index([])
    for df in dataframe_dict.values():
        all_indices = all_indices.union(df.index)
        all_columns = all_columns.union(df.columns)

    records = []
    for host, df in dataframe_dict.items():
        full_df = df.reindex(index=all_indices, columns=all_columns)
        id_column = full_df.index.name or "index"
        melted = full_df.reset_index().melt(id_vars=id_column, var_name="field", value_name="val")
        melted["host"] = host
        records.append(melted)

    if not records:
        empty = pd.DataFrame()
        return empty, empty, empty

    long_df = pd.concat(records, ignore_index=True)
    idx_col = all_indices.name or "index"

    def resolve_value(group: pd.DataFrame) -> pd.Series:
        counts = group["val"].value_counts(dropna=True)
        original_rows = group[group["host"] == original_host]
        original_value = original_rows["val"].iloc[0] if not original_rows.empty else np.nan

        if not counts.empty:
            modes = counts[counts == counts.max()].index.tolist()
            if pd.notna(original_value) and original_value in modes:
                return pd.Series([original_value, original_host], index=["golden_val", "src_host"])
            mode_value = modes[0]
            src_host = group[group["val"] == mode_value]["host"].iloc[0]
            return pd.Series([mode_value, src_host], index=["golden_val", "src_host"])

        if pd.notna(original_value):
            return pd.Series([original_value, original_host], index=["golden_val", "src_host"])

        first_valid = group["val"].first_valid_index()
        if first_valid is not None:
            return pd.Series(
                [group.loc[first_valid, "val"], group.loc[first_valid, "host"]],
                index=["golden_val", "src_host"],
            )
        return pd.Series([np.nan, original_host], index=["golden_val", "src_host"])

    golden_df = long_df.groupby([idx_col, "field"]).apply(resolve_value, include_groups=False).reset_index()
    correct_df = golden_df.pivot(index=idx_col, columns="field", values="golden_val")
    comparison = pd.merge(long_df, golden_df, on=[idx_col, "field"])
    mask = (comparison["val"] != comparison["golden_val"]) & ~(
        comparison["val"].isna() & comparison["golden_val"].isna()
    )
    diff = comparison[mask].copy()

    error_df = diff[[idx_col, "host", "field", "val", "golden_val"]].rename(
        columns={idx_col: "index", "val": "error_info", "golden_val": "new_info"}
    )
    sync_mission = diff[[idx_col, "src_host", "host", "field", "golden_val"]].rename(
        columns={idx_col: "index", "host": "dest_host", "golden_val": "new_info"}
    )
    return correct_df, error_df, sync_mission


def make_insert_sql(dataframe: pd.DataFrame, database: str, table: str) -> str:
    def format_value(value: object) -> str:
        if pd.isna(value):
            return "NULL"
        if isinstance(value, (bool, str)):
            return f"'{value}'"
        if isinstance(value, (int, float, np.number)):
            return str(value)
        return f"'{value}'"

    return "INSERT INTO {database}.{table} ({columns}) VALUES ({values});".format(
        database=database,
        table=table,
        columns=", ".join(dataframe.columns),
        values=", ".join(format_value(value) for value in dataframe.values[0]),
    )

